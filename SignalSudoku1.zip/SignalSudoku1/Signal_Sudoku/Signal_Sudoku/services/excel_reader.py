"""Excel file reading service for Signal Sudoku.

Reads I/O MDB workbooks, handles column mapping,
and prepares data for validation and allocation.
"""
import pandas as pd
import openpyxl
from typing import List, Dict, Optional, Tuple, Any, Union
from pathlib import Path
from io import BytesIO


# SIGNALSUDOKU_COMPAT_FIX: BEGIN
# Purpose: Support external MDB column aliases (e.g., 'Tag Number', 'I/O Type Name',
# 'Multipair Cable No.', 'Pair Number', 'IO Grouping') from Sample_IO_MDB_VIT_v2 1.xlsx.
# Why necessary: The incoming MDB format uses multi-word column headers. Without these
# mappings, required columns 'Tag' and 'IO' were not recognized, causing 100% allocation failure.
# Preserved behavior: Original sample aliases ('Tag', 'IO', 'Cable', 'Pair', 'Grp', 'Seg')
# and earlier aliases remain prioritized to ensure complete backward compatibility.
import re

# Known column aliases: canonical_name -> list of acceptable aliases in priority order (lowercase, stripped)
KNOWN_COLUMNS: Dict[str, List[str]] = {
    'Tag': [
        'tag', 'tag number', 'tag no.', 'tag no', 'tag_number', 'tagnumber',
        'tag name', 'tag_name', 'tagname', 'instrument tag', 'signal tag', 'signal_tag', 'tagno'
    ],
    'IO': [
        'io', 'i/o', 'i/o type name', 'io type name', 'i/o type', 'io type',
        'io_type', 'iotype', 'signal type', 'signal_type'
    ],
    'Cable': [
        'cable', 'multipair cable no.', 'multipair cable no', 'multipair cable number',
        'multipair cable', 'cable no.', 'cable no', 'cable_no', 'cable number',
        'cable_number', 'cable_id', 'cable id', 'cableno'
    ],
    'Pair': [
        'pair', 'pair number', 'pair_number', 'pair no.', 'pair no', 'pair_no', 'pairno'
    ],
    'Grp': [
        'grp', 'group', 'io grouping', 'i/o grouping', 'io_grouping', 'i/o_grouping',
        'grouping', 'logical group', 'logical_group', 'process group', 'grp_id', 'grp_no'
    ],
    'Seg': [
        'seg', 'segregation', 'segregation class', 'segregation_class', 'seg class', 'seg_class'
    ],
}
# SIGNALSUDOKU_COMPAT_FIX: END


class ExcelReader:
    """Service for reading and parsing I/O MDB Excel workbooks.

    Handles file path and BytesIO inputs, auto-detects column mappings,
    and provides preview/statistics for the Streamlit UI.
    """

    def get_sheet_names(self, file_path_or_buffer: Union[str, Path, BytesIO]) -> List[str]:
        """Return a list of sheet names in the workbook.

        Args:
            file_path_or_buffer: Path to the Excel file or a BytesIO buffer
                                 (e.g. from a Streamlit file uploader).

        Returns:
            List of sheet name strings.
        """
        if isinstance(file_path_or_buffer, BytesIO):
            file_path_or_buffer.seek(0)
        xl = pd.ExcelFile(file_path_or_buffer, engine='openpyxl')
        return xl.sheet_names

    def read_sheet(
        self,
        file_path_or_buffer: Union[str, Path, BytesIO],
        sheet_name: Optional[str] = None,
    ) -> pd.DataFrame:
        """Read the specified sheet (or the first sheet) into a DataFrame.

        Args:
            file_path_or_buffer: Path to the Excel file or a BytesIO buffer.
            sheet_name: Name of the sheet to read.  ``None`` reads the first
                        sheet.

        Returns:
            A pandas DataFrame with the sheet data.
        """
        if isinstance(file_path_or_buffer, BytesIO):
            file_path_or_buffer.seek(0)

        kwargs: Dict[str, Any] = {
            'engine': 'openpyxl',
            'dtype': str,  # read everything as strings initially to avoid data loss
        }
        if sheet_name is not None:
            kwargs['sheet_name'] = sheet_name
        else:
            kwargs['sheet_name'] = 0  # first sheet

        df = pd.read_excel(file_path_or_buffer, **kwargs)
        # Strip whitespace from column headers
        df.columns = [str(c).strip() for c in df.columns]
        return df

    # SIGNALSUDOKU_COMPAT_FIX: BEGIN
    # Purpose: Detect columns with alias prioritization and ambiguous match detection.
    # Why necessary: When multiple columns match the same canonical field (e.g. 'Tag Number'
    # vs 'TagNumber' or 'I/O Type Name' vs 'Signal Type'), prioritize the exact engineering
    # field without silently overwriting or discarding secondary columns.
    # Preserved behavior: detect_columns returns Dict[canonical, actual] as before.
    def detect_columns_with_diagnostics(
        self, df: pd.DataFrame
    ) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
        """Auto-detect column mapping and report any ambiguous/duplicate candidates.

        Returns:
            Tuple of (mapping, ambiguous_candidates) where:
            - mapping: canonical_col -> chosen_actual_col
            - ambiguous_candidates: canonical_col -> [all_matched_actual_cols]
        """
        mapping: Dict[str, str] = {}
        ambiguous: Dict[str, List[str]] = {}
        actual_columns = list(df.columns)

        def _clean_str(val: str) -> str:
            norm = val.strip().lower().replace('_', ' ').replace('-', ' ')
            return ' '.join(norm.split())

        for canonical, aliases in KNOWN_COLUMNS.items():
            candidates: List[Tuple[int, str]] = []
            for actual in actual_columns:
                actual_norm = _clean_str(actual)
                actual_alphanum = re.sub(r'[^a-z0-9]', '', actual_norm)
                for priority, alias in enumerate(aliases):
                    alias_norm = _clean_str(alias)
                    alias_alphanum = re.sub(r'[^a-z0-9]', '', alias_norm)
                    if actual_norm == alias_norm or (actual_alphanum and actual_alphanum == alias_alphanum):
                        candidates.append((priority, actual))
                        break
            if candidates:
                # Lowest priority number = highest precedence in alias list
                candidates.sort(key=lambda x: x[0])
                mapping[canonical] = candidates[0][1]
                if len(candidates) > 1:
                    ambiguous[canonical] = [c[1] for c in candidates]

        return mapping, ambiguous

    def detect_columns(self, df: pd.DataFrame) -> Dict[str, str]:
        """Auto-detect column mapping by matching known column names.

        Matching is case-insensitive, whitespace-tolerant, and alias-prioritized.

        Args:
            df: DataFrame whose columns should be inspected.

        Returns:
            Mapping of canonical column name → actual column name found in *df*.
            Only columns that were successfully matched are included.
        """
        mapping, _ = self.detect_columns_with_diagnostics(df)
        return mapping
    # SIGNALSUDOKU_COMPAT_FIX: END

    def apply_column_mapping(self, df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
        """Rename columns based on a mapping dict, returning a new DataFrame.

        Args:
            df: Source DataFrame.
            mapping: ``{canonical_name: actual_column_name}`` as produced by
                     :py:meth:`detect_columns`.

        Returns:
            A *copy* of *df* with matched columns renamed to their canonical
            names.
        """
        # Build the inverse: actual -> canonical
        rename_map = {actual: canonical for canonical, actual in mapping.items()}
        return df.rename(columns=rename_map).copy()

    def get_preview(self, df: pd.DataFrame, n_rows: int = 20) -> pd.DataFrame:
        """Return the first *n_rows* of the DataFrame for UI preview.

        Args:
            df: Source DataFrame.
            n_rows: Number of rows to include (default 20).

        Returns:
            A DataFrame with at most *n_rows* rows.
        """
        return df.head(n_rows).copy()

    def get_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Compute summary statistics about the I/O data.

        Expects a DataFrame with canonical column names (i.e. after
        :py:meth:`apply_column_mapping` has been applied).

        Args:
            df: Source DataFrame with standardised column names.

        Returns:
            Dictionary with keys:
            - ``total_rows``: total number of rows
            - ``unique_tags``: number of unique non-null Tag values
            - ``signal_types``: dict mapping each IO type to its count
            - ``cables``: number of unique non-null Cable values
            - ``groups``: number of unique non-null Grp values
        """
        stats: Dict[str, Any] = {
            'total_rows': len(df),
            'unique_tags': 0,
            'signal_types': {},
            'cables': 0,
            'groups': 0,
        }

        if 'Tag' in df.columns:
            stats['unique_tags'] = int(df['Tag'].dropna().nunique())

        if 'IO' in df.columns:
            counts = df['IO'].dropna().value_counts()
            stats['signal_types'] = {str(k): int(v) for k, v in counts.items()}
            # SIGNALSUDOKU_COMPAT_FIX: BEGIN
            # Purpose: Break down signal types into recognized vs unrecognized for diagnostics.
            # Why necessary: Provides clear diagnostic reporting on incoming MDB signal types.
            # Preserved behavior: Original stats['signal_types'] dict remains intact.
            supported_types = {'AI', 'AO', 'DI', 'DO', 'AIR', 'AOR', 'DIR', 'DOR'}
            stats['recognized_io_types'] = {
                str(k): int(v) for k, v in counts.items() if str(k).strip().upper() in supported_types
            }
            stats['unrecognized_io_types'] = {
                str(k): int(v) for k, v in counts.items() if str(k).strip().upper() not in supported_types
            }
            # SIGNALSUDOKU_COMPAT_FIX: END

        if 'Cable' in df.columns:
            stats['cables'] = int(df['Cable'].dropna().nunique())

        if 'Grp' in df.columns:
            # Exclude placeholder dashes from meaningful group count
            valid_grps = df['Grp'].dropna().apply(lambda v: str(v).strip())
            stats['groups'] = int(valid_grps[~valid_grps.isin({'-', '--', 'N/A', 'NA', ''})].nunique())

        return stats

