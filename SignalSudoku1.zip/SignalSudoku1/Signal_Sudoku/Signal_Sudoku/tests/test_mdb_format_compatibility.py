# SIGNALSUDOKU_COMPAT_FIX: BEGIN
# Purpose: Comprehensive test suite for Sample_IO_MDB_VIT_v2 compatibility,
# original sample backward compatibility, and edge-case handling.
# Preserved behavior: Runs within existing project test conventions (run_tests.py and pytest).
from copy import deepcopy
from pathlib import Path
from io import BytesIO
import pandas as pd
import pytest

from core.allocation_engine import AllocationEngine
from core.input_validation import InputValidator
from core.signal_classification import SignalClassifier, DEFAULT_CLASSIFICATION_MAP
from core.rule_validator import RuleValidator
from services.excel_reader import ExcelReader, KNOWN_COLUMNS
from services.configuration_service import DEFAULT_RULES

ROOT = Path(__file__).resolve().parents[1]
MDB_FILE = ROOT / 'sample_data' / 'Sample_IO_MDB_VIT_v2 1.xlsx'


# ===========================================================================
# Test A — Original sample files (Backward Compatibility)
# ===========================================================================

def test_original_sample_clean_file_parsing_and_allocation():
    """Verify sample_io_mdb_clean.xlsx still parses, validates, and allocates perfectly."""
    clean_path = ROOT / 'sample_data' / 'sample_io_mdb_clean.xlsx'
    assert clean_path.exists(), "Clean sample file must exist"
    df = pd.read_excel(clean_path, dtype=str).fillna('')
    assert len(df) == 79

    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert not fatal
    assert len(findings) == 0

    rules = deepcopy(DEFAULT_RULES)
    result = AllocationEngine(rules).allocate(normal)
    assert result.statistics['total_signals'] == 79
    assert result.statistics['allocated'] == 79
    assert result.statistics['unallocated'] == 0
    assert len(result.unallocated_signals) == 0


def test_original_sample_error_file_reconciliation():
    """Verify sample_io_mdb.xlsx still reconciles counts with intentional errors."""
    err_path = ROOT / 'sample_data' / 'sample_io_mdb.xlsx'
    assert err_path.exists()
    df = pd.read_excel(err_path, dtype=str).fillna('')
    assert len(df) == 83

    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert fatal  # Contains missing tag error
    assert any(f.severity == 'error' for f in findings)

    rules = deepcopy(DEFAULT_RULES)
    result = AllocationEngine(rules).allocate(normal)
    assert result.statistics['total_signals'] == 83
    assert result.statistics['allocated'] == 81
    assert result.statistics['unallocated'] == 2
    assert result.statistics['allocated'] + result.statistics['unallocated'] == 83


def test_original_sample_overflow_and_revision_b():
    """Verify sample_overflow.xlsx and sample_revision_b.xlsx work with existing behavior."""
    overflow_path = ROOT / 'sample_data' / 'sample_overflow.xlsx'
    if overflow_path.exists():
        df_overflow = pd.read_excel(overflow_path, dtype=str).fillna('')
        assert len(df_overflow) == 400
        result = AllocationEngine(deepcopy(DEFAULT_RULES)).allocate(df_overflow)
        assert result.statistics['total_signals'] == 400
        assert result.statistics['allocated'] == 400

    rev_b_path = ROOT / 'sample_data' / 'sample_revision_b.xlsx'
    if rev_b_path.exists():
        df_rev_b = pd.read_excel(rev_b_path, dtype=str).fillna('')
        assert len(df_rev_b) == 81
        result = AllocationEngine(deepcopy(DEFAULT_RULES)).allocate(df_rev_b)
        assert result.statistics['total_signals'] == 81
        assert result.statistics['allocated'] == 81


# ===========================================================================
# Test B — New MDB workbook (Sample_IO_MDB_VIT_v2 1.xlsx)
# ===========================================================================

def test_mdb_workbook_reading_and_sheet_name():
    """Verify ExcelReader reads the correct worksheet ('MDB-1') and all 190 signal rows."""
    reader = ExcelReader()
    sheet_names = reader.get_sheet_names(MDB_FILE)
    assert 'MDB-1' in sheet_names
    df = reader.read_sheet(MDB_FILE, sheet_name='MDB-1')
    assert len(df) == 190
    assert 'Tag Number' in df.columns
    assert 'I/O Type Name' in df.columns


def test_mdb_column_aliases_normalized():
    """Verify expected column aliases are normalized to canonical schema."""
    reader = ExcelReader()
    df = reader.read_sheet(MDB_FILE)
    mapping, ambiguous = reader.detect_columns_with_diagnostics(df)

    assert mapping.get('Tag') == 'Tag Number'
    assert mapping.get('IO') == 'I/O Type Name'
    assert mapping.get('Cable') == 'Multipair Cable No.'
    assert mapping.get('Pair') == 'Pair Number'
    assert mapping.get('Grp') == 'IO Grouping'

    # Secondary matching columns detected
    assert 'TagNumber' in ambiguous.get('Tag', [])
    assert 'Signal Type' in ambiguous.get('IO', [])


def test_mdb_expected_io_type_counts():
    """Verify exact baseline row counts for all eight I/O types."""
    reader = ExcelReader()
    df = reader.read_sheet(MDB_FILE)
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)

    counts = normal['IO'].value_counts().to_dict()
    assert counts.get('AI') == 47
    assert counts.get('DIR') == 39
    assert counts.get('AIR') == 29
    assert counts.get('DOR') == 27
    assert counts.get('DO') == 14
    assert counts.get('AOR') == 12
    assert counts.get('AO') == 12
    assert counts.get('DI') == 10
    assert sum(counts.values()) == 190


def test_mdb_identifiers_and_extra_columns_preserved():
    """Verify tags, cables, and extra columns (Logic Number, Charm Slot, etc.) are preserved."""
    reader = ExcelReader()
    df = reader.read_sheet(MDB_FILE)
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)

    # All 190 tags are non-empty and unique
    assert normal['Tag'].nunique() == 190
    assert (normal['Tag'] == '').sum() == 0

    # Extra engineering columns are not discarded
    assert 'TagNumber' in normal.columns
    assert 'Signal Type' in normal.columns
    assert 'Logic Number' in normal.columns
    assert 'I/O Allocation CIOC/CSLS' in normal.columns
    assert 'Charm Baseplate' in normal.columns
    assert 'Charm Slot' in normal.columns


def test_mdb_classifier_recognizes_all_eight_types():
    """Verify SignalClassifier classifies all 8 types into valid CHARMs and terminal blocks."""
    classifier = SignalClassifier()
    expected_hardware = {
        'AI': ('AI CHARM (HART)', 'Standard', 'AI'),
        'AO': ('AO CHARM', 'Standard', 'AO'),
        'DI': ('DI CHARM', 'Standard', 'DI'),
        'DO': ('High-side DO CHARM', 'Standard', 'DO'),
        'AIR': ('AI CHARM (HART)', 'Standard', 'AI'),
        'AOR': ('AO CHARM', 'Standard', 'AO'),
        'DIR': ('DI CHARM', 'Standard', 'DI'),
        'DOR': ('High-side DO CHARM', 'Standard', 'DO'),
    }
    for io_type, (expected_charm, expected_tb, expected_cat) in expected_hardware.items():
        cls = classifier.classify(io_type)
        assert cls.charm_type == expected_charm, f"Wrong charm for {io_type}: {cls.charm_type}"
        assert cls.terminal_block == expected_tb, f"Wrong TB for {io_type}: {cls.terminal_block}"
        assert cls.io_category == expected_cat, f"Wrong category for {io_type}: {cls.io_category}"
        assert cls.charm_type != 'Unknown'
        assert cls.terminal_block != 'Unknown'


def test_mdb_allocation_engine_allocates_all_190_signals():
    """Verify that all 190 signals from Sample_IO_MDB_VIT_v2 are successfully allocated."""
    reader = ExcelReader()
    df = reader.read_sheet(MDB_FILE)
    rules = deepcopy(DEFAULT_RULES)

    result = AllocationEngine(rules).allocate(df)
    stats = result.statistics

    assert stats['total_signals'] == 190
    assert stats['allocated'] == 190
    assert stats['unallocated'] == 0
    assert len(result.allocated_signals) == 190
    assert len(result.unallocated_signals) == 0
    assert stats['cabinets'] >= 1
    assert stats['ciocs'] >= 2

    # RuleValidator checks
    findings = RuleValidator(rules).validate(result)
    fatal_findings = [f for f in findings if f.severity == 'error']
    assert len(fatal_findings) == 0, f"Found unexpected fatal rule findings: {fatal_findings}"


def test_mdb_natural_pair_order():
    """Verify pair strings like 'Pair 1', 'Pair 2', 'Pair 10' sort in natural numerical order."""
    df = pd.DataFrame([
        {'Tag': 'T-01', 'IO': 'AI', 'Cable': 'C-1', 'Pair': 'Pair 10', 'Grp': '', 'Seg': ''},
        {'Tag': 'T-02', 'IO': 'AI', 'Cable': 'C-1', 'Pair': 'Pair 2', 'Grp': '', 'Seg': ''},
        {'Tag': 'T-03', 'IO': 'AI', 'Cable': 'C-1', 'Pair': 'Pair 1', 'Grp': '', 'Seg': ''},
    ])
    result = AllocationEngine(deepcopy(DEFAULT_RULES)).allocate(df)
    assigned_tags = [e['signal'].tag for e in result.allocated_signals]
    assert assigned_tags == ['T-03', 'T-02', 'T-01'], "Pair order must be 1, 2, 10"


# ===========================================================================
# Test C — Invalid or incomplete inputs (Robust Error Handling)
# ===========================================================================

def test_invalid_inputs_missing_required_tag():
    """Verify missing required 'Tag' column reports fatal missing_data error."""
    df = pd.DataFrame([
        {'IO': 'AI', 'Cable': 'C1', 'Pair': '1', 'Grp': 'G1', 'Seg': ''}
    ])
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert fatal
    tag_errors = [f for f in findings if f.field == 'Tag' and f.severity == 'error']
    assert len(tag_errors) >= 1
    assert 'Required column \'Tag\' is missing' in tag_errors[0].message


def test_invalid_inputs_missing_required_io():
    """Verify missing required 'IO' column reports fatal missing_data error."""
    df = pd.DataFrame([
        {'Tag': 'PT-101', 'Cable': 'C1', 'Pair': '1', 'Grp': 'G1', 'Seg': ''}
    ])
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert fatal
    io_errors = [f for f in findings if f.field == 'IO' and f.severity == 'error']
    assert len(io_errors) >= 1
    assert 'Required column \'IO\' is missing' in io_errors[0].message


def test_invalid_inputs_unknown_io_type():
    """Verify unknown I/O types are left unallocated with a mapping Technical Query."""
    df = pd.DataFrame([
        {'Tag': 'PT-999', 'IO': 'MYSTERY_SIGNAL', 'Cable': '', 'Pair': '', 'Grp': '', 'Seg': ''}
    ])
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert not fatal
    assert any(f.category == 'invalid_value' and 'Unknown IO type' in f.message for f in findings)

    result = AllocationEngine(deepcopy(DEFAULT_RULES)).allocate(normal)
    assert result.statistics['allocated'] == 0
    assert result.statistics['unallocated'] == 1
    assert any(tq['category'] == 'mapping' for tq in result.tq_items)


def test_invalid_inputs_missing_optional_columns():
    """Verify missing optional columns (Cable, Pair, Grp, Seg) do not crash the pipeline."""
    df = pd.DataFrame([
        {'Tag': 'T-1', 'IO': 'AI'},
        {'Tag': 'T-2', 'IO': 'DO'},
    ])
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert not fatal
    # Optional columns are filled with empty string
    for opt in ['Cable', 'Pair', 'Grp', 'Seg']:
        assert opt in normal.columns

    result = AllocationEngine(deepcopy(DEFAULT_RULES)).allocate(normal)
    assert result.statistics['allocated'] == 2
    assert result.statistics['unallocated'] == 0


def test_ambiguous_column_mappings_handled_safely():
    """Verify that multiple matching columns preserve secondary columns without overwriting."""
    df = pd.DataFrame([
        {
            'Tag Number': '320-FT-101',
            'TagNumber': '320FT101',
            'I/O Type Name': 'AIR',
            'Signal Type': '4-20 ma HART',
            'Multipair Cable No.': 'CBL-01',
            'Pair Number': 'Pair 1',
            'IO Grouping': 'PROC-A'
        }
    ])
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    findings, fatal = validator.validate(normal)
    assert not fatal

    # Canonical columns populated from preferred aliases
    assert normal.loc[0, 'Tag'] == '320-FT-101'
    assert normal.loc[0, 'IO'] == 'AIR'
    assert normal.loc[0, 'Cable'] == 'CBL-01'
    assert normal.loc[0, 'Pair'] == 'Pair 1'
    assert normal.loc[0, 'Grp'] == 'PROC-A'

    # Secondary columns preserved intact
    assert normal.loc[0, 'TagNumber'] == '320FT101'
    assert normal.loc[0, 'Signal Type'] == '4-20 ma HART'

    # Ambiguity reported in informational findings
    ambig_findings = [f for f in findings if f.category == 'mapping']
    assert len(ambig_findings) >= 2
# SIGNALSUDOKU_COMPAT_FIX: END
