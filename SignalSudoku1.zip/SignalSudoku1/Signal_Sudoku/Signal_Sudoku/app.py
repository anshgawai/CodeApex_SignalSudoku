from pathlib import Path
from io import BytesIO
import json
import pandas as pd
import streamlit as st
from core.allocation_engine import AllocationEngine
from core.input_validation import InputValidator
from core.rule_validator import RuleValidator
from core.report_generator import ReportGenerator
from core.tq_generator import TQGenerator, TechnicalQuery
from core.tq_explainer import get_category_info, lookup_allocation_status, find_related_tqs, explain_tq
from core.revision_comparator import RevisionComparator
from core.revision_workflow import RevisionWorkflow
from services.configuration_service import ConfigurationService
from services.excel_reader import ExcelReader
from services.excel_exporter import ExcelExporter

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title='Signal Sudoku', page_icon='', layout='wide')
st.title('Signal Sudoku')
st.caption(
    'Industrial I/O signal allocation • Engineering-assistance prototype • '
    'Generated allocations require review by a qualified engineer.'
)


@st.cache_data
def read_excel_bytes(data):
    return pd.read_excel(BytesIO(data), dtype=str).fillna('')


# SIGNALSUDOKU_COMPAT_FIX: BEGIN
# Purpose: Support multi-sheet workbooks and clean reading via ExcelReader.
# Why necessary: Sample_IO_MDB_VIT_v2 1.xlsx uses sheet 'MDB-1'. Using ExcelReader ensures
# consistent reading, stripping of headers, and sheet selection if multiple sheets exist.
# Preserved behavior: Default single-sheet files are read immediately as strings.
def frame_from_upload(upload):
    if upload is None:
        return None
    raw_bytes = upload.getvalue()
    sheet_names = reader.get_sheet_names(BytesIO(raw_bytes))
    sheet_to_read = None
    if len(sheet_names) > 1:
        sheet_to_read = st.selectbox('Select sheet to process', sheet_names, index=0)
    return reader.read_sheet(BytesIO(raw_bytes), sheet_name=sheet_to_read).fillna('')
# SIGNALSUDOKU_COMPAT_FIX: END


def build_tqs(input_findings, allocation_result):
    tqs = TQGenerator().generate_from_validation(input_findings)
    for idx, item in enumerate(allocation_result.tq_items, 1):
        tqs.append(TechnicalQuery(
            tq_id=f'TQ-ALLOC-{idx:04d}',
            affected_item=item['affected_item'],
            category=item['category'],
            description=item['description'],
            reason=item['reason'],
            information_needed='Confirm signal details, constraints, or available hardware.',
            suggested_action='Review the signal and project rules, then rerun allocation.',
            priority='High',
        ))
    return tqs


config = ConfigurationService(str(ROOT / 'config'))
rules = config.get_rules()
reader = ExcelReader()
reporter = ReportGenerator()
exporter = ExcelExporter()
workflow = RevisionWorkflow()
comparator = RevisionComparator()

with st.sidebar:
    st.header('Project rules')
    st.caption('Changes apply to this run. Save them to reuse them next time.')
    rules['charms_per_baseplate'] = st.number_input(
        'CHARMs per baseplate', min_value=1, max_value=64, value=int(rules['charms_per_baseplate'])
    )
    rules['baseplates_per_cioc'] = st.number_input(
        'Baseplates per CIOC', min_value=1, max_value=32, value=int(rules['baseplates_per_cioc'])
    )
    rules['ciocs_per_cabinet'] = st.number_input(
        'CIOCs per cabinet', min_value=1, max_value=16, value=int(rules['ciocs_per_cabinet'])
    )
    rules['keep_groups_together'] = st.checkbox(
        'Keep groups in same cabinet', value=rules['keep_groups_together']
    )
    rules['enforce_segregation'] = st.checkbox(
        'Keep segregation classes on separate CIOCs', value=rules['enforce_segregation']
    )
    rules['keep_cables_together'] = st.checkbox(
        'Keep cable signals on same baseplate where possible', value=rules['keep_cables_together']
    )
    rules['maintain_pair_order'] = st.checkbox(
        'Order signals by cable pair', value=rules['maintain_pair_order']
    )
    rules['reserve_spare_capacity'] = st.checkbox(
        'Reserve spare capacity', value=rules['reserve_spare_capacity']
    )
    if rules['reserve_spare_capacity']:
        rules['spare_percentage'] = st.slider(
            'Spare capacity (%)', 0.0, 50.0, float(rules.get('spare_percentage', 10.0)), step=1.0
        )
    rules['default_do_subtype'] = st.selectbox(
        'Default DO hardware',
        ['normal', 'solenoid', 'relay'],
        index=['normal', 'solenoid', 'relay'].index(rules.get('default_do_subtype', 'normal')),
    )
    if st.button('Save rules', use_container_width=True):
        errors = config.validate_rules(rules)
        if errors:
            st.error('\n'.join(errors))
        else:
            config.save_rules(rules)
            st.success('Rules saved.')
    if st.button('Reset defaults', use_container_width=True):
        config.reset_to_defaults()
        st.rerun()

left, right = st.columns([3, 2])
with left:
    st.subheader('1. Upload I/O MDB')
    uploaded = st.file_uploader('Choose an Excel file', type=['xlsx', 'xlsm', 'xls'])
    use_sample = st.checkbox('Use generated synthetic sample data instead', value=uploaded is None)
    sample_path = ROOT / 'sample_data' / 'sample_io_mdb_clean.xlsx'
    if use_sample:
        if not sample_path.exists():
            st.info('Sample file not generated yet. Run: python sample_data/create_sample_data.py')
            df = None
        else:
            df = pd.read_excel(sample_path, dtype=str).fillna('')
    else:
        df = frame_from_upload(uploaded)
with right:
    st.subheader('2. Input preview')
    if df is not None:
        st.metric('Input signals', len(df))
        st.dataframe(df.head(10), use_container_width=True, hide_index=True)

if df is not None:
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    input_findings, fatal = validator.validate(normal)
    with st.expander(f'Input checks ({len(input_findings)} findings)', expanded=bool(fatal)):
        if input_findings:
            st.dataframe(
                pd.DataFrame([f.__dict__ for f in input_findings]),
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.success('No input validation findings.')

    # SIGNALSUDOKU_COMPAT_FIX: BEGIN
    # Purpose: Provide concise ingestion diagnostics (rows read, valid tags, recognized/unrecognized IO types, column mappings).
    # Why necessary: Allows engineers to verify that external MDB columns and all 190 signal rows are parsed correctly.
    # Preserved behavior: Kept within an optional expander so default UI appearance is preserved.
    with st.expander('Ingestion & Mapping Diagnostics', expanded=False):
        d_stats = reader.get_statistics(normal)
        d_map = getattr(validator, '_last_mapping', {})
        d_amb = getattr(validator, '_last_ambiguous', {})
        d1, d2, d3 = st.columns(3)
        d1.metric('Rows read', d_stats['total_rows'])
        d1.metric('Unique tags', d_stats['unique_tags'])
        d2.metric('Cables', d_stats['cables'])
        d2.metric('Groups', d_stats['groups'])
        rec_count = sum(d_stats.get('recognized_io_types', {}).values())
        unrec_count = sum(d_stats.get('unrecognized_io_types', {}).values())
        d3.metric('Recognized IO types', rec_count)
        d3.metric('Unrecognized IO types', unrec_count)

        if d_stats.get('recognized_io_types'):
            st.caption('**Recognized I/O types:** ' + ', '.join(f'{k}: {v}' for k, v in sorted(d_stats['recognized_io_types'].items())))
        if d_stats.get('unrecognized_io_types'):
            st.warning('**Unrecognized I/O types:** ' + ', '.join(f'{k}: {v}' for k, v in sorted(d_stats['unrecognized_io_types'].items())))
        if d_map:
            st.caption('**Column mappings:** ' + ', '.join(f'{canonical} \u2190 {actual}' for canonical, actual in d_map.items()))
        if d_amb:
            st.caption('**Preserved secondary columns:** ' + ', '.join(f'{canonical}: {cols}' for canonical, cols in d_amb.items()))
    # SIGNALSUDOKU_COMPAT_FIX: END
    if st.button('Allocate signals', type='primary', use_container_width=True):
        errors = config.validate_rules(rules)
        if errors:
            st.error('Fix rule settings first: ' + '; '.join(errors))
        else:
            try:
                result = AllocationEngine(rules).allocate(normal)
                findings = RuleValidator(rules).validate(result)
                tqs = build_tqs(input_findings, result)
                session = workflow.start_from_allocation(
                    df=normal,
                    rules=rules,
                    allocation_result=result,
                    validation_findings=findings,
                    input_findings=input_findings,
                    tqs=tqs,
                )
                st.session_state['allocation'] = {
                    'result': result,
                    'findings': findings,
                    'tqs': tqs,
                    'df': normal,
                    'rules': rules,
                    'input_findings': input_findings,
                }
                st.session_state['revision_session'] = session
                # Clear any prior proposed revision and selection states when reallocating from scratch.
                st.session_state.pop('proposed_revision', None)
                st.session_state.pop('selected_tq_id', None)
                st.session_state.pop('tq_select', None)
                st.session_state.pop('_last_tq_table_rows', None)
                st.session_state.pop('tq_table', None)
            except Exception as exc:
                st.error(f'Allocation failed: {exc}')

if 'allocation' in st.session_state:
    saved = st.session_state['allocation']
    result = saved['result']
    findings = saved['findings']
    tqs = saved['tqs']
    rules_used = saved['rules']
    input_findings = saved.get('input_findings', [])
    session = st.session_state.get('revision_session')

    st.divider()
    st.subheader('3. Results')
    # NOTE (Allocation Count Fix): Reconcile Results metrics so that Signals == Allocated + Unallocated.
    # Total signals accounts for all input rows (e.g. 83), allocated signals represents successfully
    # placed slots (81), and unallocated signals accounts for failed/duplicate/invalid rows (2).
    m = result.statistics
    cols = st.columns(5)
    cols[0].metric('Signals', m['total_signals'], help='Total input signal rows processed')
    cols[1].metric('Allocated', m['allocated'], help='Signals successfully allocated to CHARM slots')
    cols[2].metric('Unallocated', m['unallocated'], help='Signals that could not be allocated')
    cols[3].metric('Cabinets', m['cabinets'])
    cols[4].metric('CIOCs', m['ciocs'])

    # Display clear breakdown when distinct input rows and unique signal tags differ due to duplicates
    if m.get('unique_signals') and m['unique_signals'] < m['total_signals']:
        dup_count = m['total_signals'] - m['unique_signals']
        st.caption(
            f"Note: {m['total_signals']} input rows ({m['unique_signals']} unique tags). "
            f"{m['allocated']} allocated, {m['unallocated']} unallocated "
            f"({dup_count} duplicate tag row{'s' if dup_count > 1 else ''}, "
            f"{m['unallocated'] - dup_count} unplaced)."
        )

    # Use the corrected unallocated count in the warning banner
    if m['unallocated']:
        st.warning(
            f"{m['unallocated']} signal(s) could not be allocated. "
            'Each has a technical query; review before treating this as complete.'
        )
        # SIGNALSUDOKU_COMPAT_FIX: BEGIN
        # Purpose: Report exact breakdown of allocation failure reasons.
        # Why necessary: Provides transparency into why any signals failed allocation under active rules.
        # Preserved behavior: Existing TQ and warning displays remain unchanged.
        with st.expander('Allocation Failure Diagnostics', expanded=True):
            reason_counts = {}
            for tq in result.tq_items:
                r = tq.get('reason', 'Unknown reason')
                reason_counts[r] = reason_counts.get(r, 0) + 1
            for reason, cnt in reason_counts.items():
                st.write(f"- **{reason}**: {cnt} signal(s)")
        # SIGNALSUDOKU_COMPAT_FIX: END
    else:
        st.success(
            'Every signal received a slot. Review validation findings before accepting the result.'
        )

    allocation_df = reporter.generate_allocation_table(result)
    validation_df = reporter.generate_validation_report(findings)
    tq_df = reporter.generate_tq_report(tqs)
    hardware_df = reporter.generate_hardware_summary(result)
    config_df = reporter.generate_configuration_report(rules_used)

    # ----- Detected conflicts -----
    if session and session.analysis:
        st.subheader('4. Detected conflicts')
        summary = session.analysis.summary
        c1, c2, c3, c4 = st.columns(4)
        c1.metric('Source data', summary.get('source_data', 0))
        c2.metric('Assignment', summary.get('assignment', 0))
        c3.metric('Configurable rule', summary.get('configurable_rule', 0))
        c4.metric('Hard constraint', summary.get('hard_constraint', 0))
        problems_df = reporter.generate_problems_report(session.analysis.problems)
        if problems_df.empty:
            st.success('No classified conflicts beyond a clean allocation.')
        else:
            st.dataframe(problems_df, use_container_width=True, hide_index=True)
            st.caption(
                'Source data must be corrected in the MDB. Hard constraints cannot be bypassed. '
                'Configurable preferences may be reviewed below.'
            )

    tabs = st.tabs([
        'Allocation',
        'Rule checks',
        'Technical queries',
        'Hardware summary',
        'Rule Change Suggestions',
        'Proposed revision',
        'Revision comparison',
    ])

    with tabs[0]:
        st.dataframe(allocation_df, use_container_width=True, hide_index=True)
    with tabs[1]:
        if validation_df.empty:
            st.success('No rule violations found by the current validator.')
        else:
            st.dataframe(validation_df, use_container_width=True, hide_index=True)
    with tabs[2]:
        if tq_df.empty:
            st.info('No technical queries generated.')
        else:
            tq_left, tq_right = st.columns([3, 2])
            tq_ids = [tq.tq_id for tq in tqs]
            tq_options = {
                f"{tq.tq_id} — {tq.affected_item or 'Unknown'} ({tq.category})": tq.tq_id
                for tq in tqs
            }
            tq_id_to_label = {v: k for k, v in tq_options.items()}
            label_list = list(tq_options.keys())

            # NOTE (TQ Explanations - Selection Sync): Two-way synchronization between table clicks and selector.
            # If a user clicks a row in the dataframe, update the selected TQ and synchronize the dropdown widget.
            table_state = st.session_state.get('tq_table', {})
            table_rows = []
            if hasattr(table_state, 'selection') and hasattr(table_state.selection, 'rows'):
                table_rows = list(table_state.selection.rows)
            elif isinstance(table_state, dict):
                table_rows = list(table_state.get('selection', {}).get('rows', []))

            last_rows = st.session_state.get('_last_tq_table_rows', [])
            if table_rows and table_rows != last_rows:
                st.session_state['_last_tq_table_rows'] = table_rows
                clicked_idx = table_rows[0]
                if 0 <= clicked_idx < len(tqs):
                    clicked_id = tqs[clicked_idx].tq_id
                    st.session_state['selected_tq_id'] = clicked_id
                    st.session_state['tq_select'] = tq_id_to_label.get(clicked_id, label_list[0])

            # Ensure an active selection exists so explanations remain visible from the start
            if 'selected_tq_id' not in st.session_state or st.session_state['selected_tq_id'] not in tq_ids:
                st.session_state['selected_tq_id'] = tq_ids[0]
                st.session_state['tq_select'] = tq_id_to_label.get(tq_ids[0], label_list[0])

            with tq_left:
                st.markdown('##### Technical Queries')
                cur_id = st.session_state.get('selected_tq_id', tq_ids[0])
                cur_label = tq_id_to_label.get(cur_id, label_list[0])
                cur_index = label_list.index(cur_label) if cur_label in label_list else 0

                selected_label = st.selectbox(
                    'Select a TQ to see its explanation',
                    options=label_list,
                    index=cur_index,
                    key='tq_select',
                )
                if selected_label in tq_options:
                    chosen_id = tq_options[selected_label]
                    if chosen_id != st.session_state.get('selected_tq_id'):
                        st.session_state['selected_tq_id'] = chosen_id

                df_selection = st.dataframe(
                    tq_df,
                    use_container_width=True,
                    hide_index=True,
                    on_select='rerun',
                    selection_mode='single-row',
                    key='tq_table',
                )

                # Check if click just occurred on the dataframe in this run
                new_table_rows = []
                if hasattr(df_selection, 'selection') and hasattr(df_selection.selection, 'rows'):
                    new_table_rows = list(df_selection.selection.rows)
                elif isinstance(df_selection, dict):
                    new_table_rows = list(df_selection.get('selection', {}).get('rows', []))

                if new_table_rows and new_table_rows != st.session_state.get('_last_tq_table_rows', []):
                    st.session_state['_last_tq_table_rows'] = new_table_rows
                    c_idx = new_table_rows[0]
                    if 0 <= c_idx < len(tqs):
                        c_id = tqs[c_idx].tq_id
                        if c_id != st.session_state.get('selected_tq_id'):
                            st.session_state['selected_tq_id'] = c_id
                            st.session_state['tq_select'] = tq_id_to_label.get(c_id, label_list[0])
                            st.rerun()

            with tq_right:
                st.markdown('##### TQ Explanation')
                # NOTE (TQ Explanations - Concise Display):
                # Displays concise, single-sentence-per-section explanation derived from actual application data.
                # Retains strictly: Meaning, Why flagged, Affected item, Impact, Recommended action,
                # Allocation status, and Related TQs (when reliably linked).
                active_id = st.session_state.get('selected_tq_id', tq_ids[0])
                sel_tq = next((t for t in tqs if t.tq_id == active_id), tqs[0] if tqs else None)
                if sel_tq is not None:
                    explanation = explain_tq(sel_tq, result, tqs)
                    st.markdown(f"**Meaning:**  \n{explanation['meaning']}")
                    st.markdown(f"**Why flagged:**  \n{explanation['why_flagged']}")
                    st.markdown(f"**Affected item:**  \n{explanation['affected_item']}")
                    st.markdown(f"**Impact:**  \n{explanation['impact']}")
                    st.markdown(f"**Recommended action:**  \n{explanation['recommended_action']}")
                    st.markdown(f"**Allocation status:**  \n{explanation['allocation_status']}")
                    if explanation['related_tqs']:
                        st.markdown('**Related TQs:**')
                        for r in explanation['related_tqs']:
                            st.markdown(f"- `{r['tq_id']}` ({r['category']}): {r['description']}")
    with tabs[3]:
        st.dataframe(hardware_df, use_container_width=True, hide_index=True)

    with tabs[4]:
        st.write(
            'Review permissible configurable preference changes. '
            'Hard constraints (segregation, CHARM mapping, physical capacity invariants) '
            'are never suggested for weakening. Selected changes are **not** applied until you approve.'
        )
        if not session:
            st.info('Allocate signals first to generate suggestions.')
        elif session.analysis and session.analysis.summary.get('fully_valid'):
            st.success('Allocation is already valid under current rules — no rule changes needed.')
        else:
            sug_result = session.suggestion_result
            if sug_result and sug_result.no_solution_reason and not session.suggestions:
                st.warning(sug_result.no_solution_reason)
                if sug_result.hard_blockers:
                    st.write('Hard constraint blockers:')
                    st.dataframe(
                        reporter.generate_problems_report(sug_result.hard_blockers),
                        use_container_width=True,
                        hide_index=True,
                    )
            if session.suggestions:
                sug_rows = []
                for s in session.suggestions:
                    sug_rows.append({
                        'ID': s.suggestion_id,
                        'Rule': s.rule_key,
                        'Current': str(s.current_value),
                        'Proposed': str(s.proposed_value),
                        'Conflict': s.conflict_resolved,
                        'Expected impact': s.expected_impact,
                        'Warnings': '; '.join(s.warnings),
                    })
                st.dataframe(pd.DataFrame(sug_rows), use_container_width=True, hide_index=True)

                selected = st.multiselect(
                    'Select suggestions to approve',
                    options=[s.suggestion_id for s in session.suggestions],
                    format_func=lambda sid: next(
                        (
                            f"{s.suggestion_id}: {s.rule_key} "
                            f"{s.current_value} → {s.proposed_value}"
                            for s in session.suggestions if s.suggestion_id == sid
                        ),
                        sid,
                    ),
                    key='selected_suggestions',
                )
                col_a, col_b = st.columns(2)
                with col_a:
                    if st.button(
                        'Approve selected & reallocate',
                        type='primary',
                        use_container_width=True,
                        disabled=not selected,
                    ):
                        try:
                            updated = workflow.approve_and_reallocate(
                                session, selected, input_findings=input_findings
                            )
                            st.session_state['revision_session'] = updated
                            # Build proposed export artefacts
                            rev_alloc_df = reporter.generate_allocation_table(updated.revised_result)
                            rev_val_df = reporter.generate_validation_report(updated.revised_findings)
                            rev_tq_df = reporter.generate_tq_report(updated.revised_tqs)
                            rev_hw_df = reporter.generate_hardware_summary(updated.revised_result)
                            rev_cfg_df = reporter.generate_configuration_report(updated.approved_rules)
                            rules_rows = workflow.rule_change_summary_rows(updated)
                            rules_df = reporter.generate_approved_rules_report(rules_rows)
                            summary_df = reporter.generate_change_summary_report(
                                workflow.change_summary_dict(updated)
                            )
                            cmp = comparator.compare_allocations(allocation_df, rev_alloc_df)
                            cmp_df = reporter.generate_allocation_comparison_report(cmp)
                            workbook = exporter.export_proposed_revision(
                                rev_alloc_df,
                                rev_val_df,
                                rev_tq_df,
                                rev_hw_df,
                                rev_cfg_df,
                                summary_df,
                                rules_df,
                                comparison_df=cmp_df,
                                is_fully_valid=updated.is_fully_valid,
                                is_diagnostic=not updated.is_fully_valid,
                            )
                            st.session_state['proposed_revision'] = {
                                'session': updated,
                                'allocation_df': rev_alloc_df,
                                'validation_df': rev_val_df,
                                'tq_df': rev_tq_df,
                                'hardware_df': rev_hw_df,
                                'config_df': rev_cfg_df,
                                'summary_df': summary_df,
                                'rules_df': rules_df,
                                'comparison': cmp,
                                'comparison_df': cmp_df,
                                'workbook': workbook.getvalue(),
                            }
                            st.rerun()
                        except Exception as exc:
                            st.error(f'Reallocation failed: {exc}')
                with col_b:
                    if st.button('Cancel (keep original rules)', use_container_width=True):
                        workflow.cancel(session)
                        st.session_state['revision_session'] = session
                        st.session_state.pop('proposed_revision', None)
                        st.info(
                            'Cancelled. Original rules and uploaded data are unchanged. '
                            'Sidebar project rules were not permanently overwritten.'
                        )

    with tabs[5]:
        proposed = st.session_state.get('proposed_revision')
        if not proposed:
            st.info(
                'Approve rule changes in **Rule Change Suggestions** to generate a proposed revision.'
            )
        else:
            upd = proposed['session']
            if upd.is_fully_valid:
                st.success(
                    'Proposed allocation satisfies hard constraints with no unallocated signals. '
                    'Still requires qualified engineering review.'
                )
            else:
                st.error(
                    'Proposed reallocation did not produce a fully valid result. '
                    'Remaining conflicts are shown below — reconsider suggestions or fix source data. '
                    'You may download a labelled diagnostic report (not a successful revision).'
                )

            rm = upd.revised_result.statistics
            rcols = st.columns(4)
            rcols[0].metric('Allocated', rm.get('allocated', 0))
            rcols[1].metric('Unallocated', rm.get('unallocated', 0))
            rcols[2].metric('Rule changes applied', len(upd.approved_suggestions))
            rcols[3].metric('Fully valid', 'Yes' if upd.is_fully_valid else 'No')

            st.write('Approved rule changes (session only — original config file unchanged):')
            st.dataframe(proposed['rules_df'], use_container_width=True, hide_index=True)
            st.write('Proposed allocation:')
            st.dataframe(proposed['allocation_df'], use_container_width=True, hide_index=True)
            if not proposed['validation_df'].empty:
                st.write('Remaining validation findings:')
                st.dataframe(proposed['validation_df'], use_container_width=True, hide_index=True)

            fname = (
                'signal_sudoku_proposed_revision.xlsx'
                if upd.is_fully_valid
                else 'signal_sudoku_diagnostic_report.xlsx'
            )
            st.download_button(
                'Download proposed revision workbook (.xlsx)'
                if upd.is_fully_valid
                else 'Download diagnostic report (.xlsx)',
                data=proposed['workbook'],
                file_name=fname,
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                type='primary',
            )

            st.write('Original vs proposed allocation comparison:')
            st.json(proposed['comparison'].summary)
            st.dataframe(proposed['comparison_df'], use_container_width=True, hide_index=True)
            cmp_book = exporter.export_revision_report(proposed['comparison_df'])
            st.download_button(
                'Download allocation comparison report (.xlsx)',
                data=cmp_book.getvalue(),
                file_name='signal_sudoku_allocation_comparison.xlsx',
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

    with tabs[6]:
        st.write(
            'Upload a later revision to compare signal tags and source fields '
            '(existing MDB-vs-MDB workflow).'
        )
        proposed = st.session_state.get('proposed_revision')
        if proposed:
            st.info(
                'A proposed revision is available. Use the **Proposed revision** tab to compare '
                'the original allocation with the automatically generated revision, '
                'or upload a separate Revision B file below.'
            )
        rev_upload = st.file_uploader(
            'Revision B Excel file', type=['xlsx', 'xlsm', 'xls'], key='revision_b'
        )
        if rev_upload:
            rev_b = frame_from_upload(rev_upload)
            rev_result = RevisionComparator().compare(
                saved['df'], InputValidator().normalize_dataframe(rev_b)
            )
            rev_rows = []
            for kind, changes in [
                ('Added', rev_result.added),
                ('Deleted', rev_result.deleted),
                ('Modified', rev_result.modified),
                ('Unchanged', rev_result.unchanged),
            ]:
                for change in changes:
                    rev_rows.append({
                        'Tag': change.tag,
                        'Change': kind,
                        'Changed fields': json.dumps(change.changed_fields, ensure_ascii=False),
                    })
            st.json(rev_result.summary)
            st.dataframe(pd.DataFrame(rev_rows), use_container_width=True, hide_index=True)
            mdb_cmp_df = reporter.generate_allocation_comparison_report(rev_result)
            mdb_book = exporter.export_revision_report(mdb_cmp_df)
            st.download_button(
                'Download MDB revision comparison (.xlsx)',
                data=mdb_book.getvalue(),
                file_name='signal_sudoku_mdb_revision_comparison.xlsx',
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

    workbook = exporter.export_allocation(
        allocation_df, validation_df, tq_df, hardware_df, config_df
    )
    st.download_button(
        'Download allocation workbook (.xlsx)',
        data=workbook.getvalue(),
        file_name='signal_sudoku_allocation.xlsx',
        mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        type='primary',
    )
else:
    st.info('Upload an Excel file or select the synthetic sample, then click **Allocate signals**.')
