import pandas as pd
from services.excel_reader import ExcelReader
from core.allocation_engine import AllocationEngine, Signal
from core.report_generator import ReportGenerator

def test_normalized_tag_joins_and_deleted_records():
    reader = ExcelReader()

    alloc_df = pd.DataFrame({
        'Tag Name': ['FIT-101', 'PIT-102 ', 'TIT-103'],
        'IO Type': ['AI', 'AI', 'AI']
    })

    mdb_df = pd.DataFrame({
        'Tag Number': ['FIT101', 'PIT-102', 'TIT-103', 'LIT-999'],
        'Status': ['Active', 'Active', 'DELETED', 'Active'],
        'Process Function Type': ['Flow Transmitter', 'Pressure Transmitter', 'Temperature Transmitter', 'Level Transmitter'],
        'Discrete Alarm Priority': ['HIGH', 'MEDIUM', 'LOW', 'LOG']
    })

    merged, report = reader.merge_mdb_allocation(alloc_df, mdb_df)

    assert len(merged) == 3
    assert report['matched_count'] == 2  # FIT-101 and PIT-102 (TIT-103 is DELETED in MDB)
    assert 'TIT-103' in report['deleted_mdb_tags'] or 'TIT-103' in report['allocation_only_tags']
    assert 'LIT-999' in report['active_unmatched_mdb_tags']

def test_criticality_levels_confirmed_inferred_unassessed():
    rules = {
        'criticality_rules': {
            'inferred_mappings': {
                'ProcessFunction': {
                    'Control Valve': 'P2 Control/Final Element'
                }
            },
            'overrides': {
                'XV-101': 'P1 Safety/Protection'
            }
        }
    }

    engine = AllocationEngine(rules)

    # 1. Confirmed via override
    sig1 = engine._make_signal({'Tag': 'XV-101', 'IO': 'DO', 'ProcessFunction': 'Control Valve'})
    assert sig1.criticality == 'P1 Safety/Protection'
    assert sig1.criticality_status == 'confirmed'

    # 2. Inferred via candidate rule
    sig2 = engine._make_signal({'Tag': 'FCV-102', 'IO': 'AO', 'ProcessFunction': 'Control Valve'})
    assert sig2.criticality == 'P2 Control/Final Element'
    assert sig2.criticality_status == 'inferred'

    # 3. Unassessed default
    sig3 = engine._make_signal({'Tag': 'TT-103', 'IO': 'AI', 'ProcessFunction': 'Temperature Element'})
    assert sig3.criticality == 'Unassessed'
    assert sig3.criticality_status == 'unassessed'

def test_spare_inactive_handling():
    # Keep Spare/Inactive as a separate lifecycle status, not a criticality tier
    engine = AllocationEngine({})
    sig = engine._make_signal({'Tag': 'SPARE-01', 'IO': 'AI', 'TagStatus': 'Spare'})
    assert sig.tag_status == 'Spare'
    assert sig.criticality == 'Unassessed'

def test_issue_sorting_by_criticality_and_severity():
    # Error whose priority changes its ordering but not its severity
    reporter = ReportGenerator()

    # Let's mock AllocationResult
    class DummySlot:
        cabinet_id = 'CAB-01'
        cioc_id = 'CIOC-01'
        baseplate_id = 'BP-01'
        charm_id = 'CH-01'

    class DummyResult:
        allocated_signals = []
        unallocated_signals = [
            Signal(tag='TT-01', io_type='AI', criticality='P3 Process Measurement/Operator Alarm', criticality_status='unassessed'),
            Signal(tag='XV-01', io_type='DO', criticality='P1 Safety/Protection', criticality_status='confirmed'),
        ]
        cabinets = []

    findings = [
        type('obj', (object,), {'tag': 'TT-01', 'severity': 'error', 'category': 'test', 'finding_id': 'INP-001', 'message': 'err', 'suggestion': ''}),
        type('obj', (object,), {'tag': 'XV-01', 'severity': 'error', 'category': 'test', 'finding_id': 'INP-002', 'message': 'err', 'suggestion': ''}),
    ]

    df = reporter.generate_allocation_table(DummyResult(), findings=findings)
    # XV-01 is P1 (order 0), TT-01 is P3 (order 2). Even though both have 'error' severity,
    # XV-01 should come first because Criticality takes precedence in sorting.
    assert df.iloc[0]['Tag'] == 'XV-01'
    assert df.iloc[1]['Tag'] == 'TT-01'
    assert df.iloc[0]['Validation_Severity'] == 'error'
    assert df.iloc[1]['Validation_Severity'] == 'error'

def test_no_safety_criticality_inferred_from_unreliable_fields():
    # Requirement 2: Do not infer safety criticality from Risk Area, Segregation,
    # NON-IS / IS, instrument type, or the word General.
    engine = AllocationEngine({})
    test_cases = [
        {'Tag': 'S-1', 'IO': 'AI', 'Risk Area': 'Zone 1', 'Segregation': 'IS', 'NON-IS / IS': 'IS'},
        {'Tag': 'S-2', 'IO': 'DI', 'Instrument Type': 'Emergency Shutdown Switch', 'Instrument Type Description': 'ESD Trip'},
        {'Tag': 'S-3', 'IO': 'DO', 'ProcessFunction': 'General Service Valve', 'Risk Area': 'Hazardous'},
    ]
    for tc in test_cases:
        sig = engine._make_signal(tc)
        assert sig.criticality != 'P1 Safety/Protection'
        assert sig.criticality_status != 'confirmed'

def test_alarm_priority_separate_from_criticality_and_blank_preserved():
    # Requirement 3: Treat Discrete Alarm Priority as alarm handling priority,
    # separate from equipment criticality. Do not treat blank alarm-priority fields as low priority.
    engine = AllocationEngine({})
    sig_advisory = engine._make_signal({'Tag': 'A-1', 'IO': 'AI', 'Discrete Alarm Priority': 'ADVISORY'})
    assert sig_advisory.alarm_priority == 'ADVISORY'
    assert sig_advisory.criticality == 'Unassessed'

    sig_blank = engine._make_signal({'Tag': 'B-1', 'IO': 'AI', 'Discrete Alarm Priority': ''})
    assert sig_blank.alarm_priority == ''
    assert sig_blank.criticality == 'Unassessed'

def test_validation_report_sorting_by_criticality_and_severity():
    reporter = ReportGenerator()
    class DummyResult:
        allocated_signals = []
        unallocated_signals = [
            Signal(tag='P3-ERR', io_type='AI', criticality='P3 Process Measurement/Operator Alarm', alarm_priority='LOG'),
            Signal(tag='P1-WRN', io_type='DO', criticality='P1 Safety/Protection', alarm_priority='HIGH'),
            Signal(tag='P1-ERR', io_type='DO', criticality='P1 Safety/Protection', alarm_priority='CRITICAL'),
        ]
        cabinets = []

    findings = [
        type('obj', (object,), {'tag': 'P3-ERR', 'severity': 'error', 'category': 'test', 'finding_id': 'F-1', 'message': 'm1', 'suggestion': '', 'field': ''}),
        type('obj', (object,), {'tag': 'P1-WRN', 'severity': 'warning', 'category': 'test', 'finding_id': 'F-2', 'message': 'm2', 'suggestion': '', 'field': ''}),
        type('obj', (object,), {'tag': 'P1-ERR', 'severity': 'error', 'category': 'test', 'finding_id': 'F-3', 'message': 'm3', 'suggestion': '', 'field': ''}),
    ]

    val_df = reporter.generate_validation_report(findings, allocation_result=DummyResult())
    # Expected sort order:
    # 1. P1-ERR (Criticality: P1, Severity: error)
    # 2. P1-WRN (Criticality: P1, Severity: warning)
    # 3. P3-ERR (Criticality: P3, Severity: error)
    assert list(val_df['Tag']) == ['P1-ERR', 'P1-WRN', 'P3-ERR']
    assert list(val_df['Criticality']) == ['P1 Safety/Protection', 'P1 Safety/Protection', 'P3 Process Measurement/Operator Alarm']
    assert list(val_df['Severity']) == ['error', 'warning', 'error']

def test_single_input_mdb_direct_allocation():
    from core.input_validation import InputValidator
    from core.allocation_engine import AllocationEngine

    mdb_raw = pd.DataFrame({
        'Tag Number': ['FIT-101', 'PIT-102', 'XV-103', 'HV-104'],
        'I/O Type Name': ['AIR', 'AI', 'DIR', 'DOR'],
        'Instrument Type': ['FT', 'PT', 'XV', 'HV'],
        'Instrument Type Description': ['Flow Transmitter', 'Pressure Transmitter', 'Shutdown Valve', 'Hand Valve'],
        'Multi-cable / Cable': ['C-01', 'C-01', 'C-02', 'C-02'],
        'Pair Number': ['1', '2', '1', '2'],
        'Process Function Type': ['Flow Transmitter', 'Pressure Transmitter', 'ESD Valve', 'Control Valve'],
        'Discrete Alarm Priority': ['ADVISORY', '', 'CRITICAL', 'LOG'],
        'Status': ['Active', 'Active', 'Active', 'Active']
    })

    validator = InputValidator()
    normal = validator.normalize_dataframe(mdb_raw)

    # Verify no column collision or duplicate columns
    assert not normal.columns.duplicated().any()
    assert 'Tag' in normal.columns
    assert 'IO' in normal.columns
    assert 'InstrumentType' in normal.columns

    # Verify redundant IO types pass validation without fatal errors
    findings, has_fatal = validator.validate(normal)
    assert not has_fatal

    # Verify single input allocates cleanly
    from services.configuration_service import ConfigurationService
    from pathlib import Path
    config_dir = Path(__file__).resolve().parent.parent / 'config'
    rules = ConfigurationService(str(config_dir)).get_rules() if config_dir.exists() else {}
    engine = AllocationEngine(rules)
    result = engine.allocate(normal)
    assert len(result.allocated_signals) == 4
    assert len(result.unallocated_signals) == 0


