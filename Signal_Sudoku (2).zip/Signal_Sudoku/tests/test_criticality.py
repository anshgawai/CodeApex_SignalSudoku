"""Tests for CriticalityClassifier."""
import pytest
from core.criticality_classifier import CriticalityClassifier, CriticalityResult, CRITICALITY_TIERS
from services.excel_reader import ExcelReader
import pandas as pd

def test_confirmed_override_takes_precedence():
    clf = CriticalityClassifier(overrides={'100-psh-001': 'P1 Safety/Protection'})
    result = clf.classify({'Tag': '100-PSH-001', 'Process_Function': 'control valve'})
    assert result.tier == 'P1 Safety/Protection'
    assert result.status == 'confirmed'

def test_confirmed_override_normalized_tag():
    """Override matching must normalize whitespace and case."""
    clf = CriticalityClassifier(overrides={'100 psh 001': 'P1 Safety/Protection'})
    result = clf.classify({'Tag': '100-PSH-001', 'Process_Function': ''})
    # Tag normalization strips hyphens? No — we only casefold+strip+collapse spaces.
    # '100-PSH-001'.casefold() == '100-psh-001', override key '100 psh 001' != '100-psh-001'
    # So this should NOT match (hyphens preserved). Verify unassessed.
    assert result.status == 'unassessed'

def test_inferred_control_valve_marked_as_inferred():
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': 'FV-100', 'Process_Function': 'Control Valve actuator'})
    assert result.tier == 'P2 Control/Final Element'
    assert result.status == 'inferred'
    assert '[INFERRED' in result.note

def test_unassessed_default_for_unknown():
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': 'MISC-001', 'Process_Function': ''})
    assert result.tier == 'Unassessed'
    assert result.status == 'unassessed'

def test_spare_tag_status_is_lifecycle_not_criticality():
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': '100-PT-001', 'Tag_Status': 'Spare', 'Process_Function': 'control valve'})
    # Even though process_function matches P2, spare lifecycle takes precedence
    assert result.lifecycle == 'Spare'
    assert result.tier == 'Unassessed'  # spare = no criticality assignment

def test_inactive_tag_status_lifecycle():
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': 'X-001', 'Tag_Status': 'inactive'})
    assert result.lifecycle == 'Inactive'
    assert result.tier == 'Unassessed'

def test_deleted_mdb_record_lifecycle():
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': 'DEL-001', 'Tag_Status': 'deleted'})
    assert result.lifecycle == 'Deleted'
    assert result.tier == 'Unassessed'

def test_normalized_tag_join_whitespace_case():
    reader = ExcelReader()
    alloc_df = pd.DataFrame([{'Tag': '  100-PT-001  ', 'IO': 'AI', 'Status': 'Allocated'}])
    mdb_df = pd.DataFrame([{
        'Tag Number': '100-PT-001',
        'Equipment Name': 'PT-001-EQ',
        'Process Function Type': 'Pressure Measurement',
    }])
    merged, report = reader.merge_mdb_allocation(alloc_df, mdb_df)
    assert report['matched_count'] == 1
    assert report['allocation_only_tags'] == []
    assert report['active_unmatched_mdb_tags'] == []

def test_deleted_mdb_excluded_from_join():
    reader = ExcelReader()
    alloc_df = pd.DataFrame([{'Tag': '100-PT-001', 'IO': 'AI', 'Status': 'Allocated'}])
    mdb_df = pd.DataFrame([{
        'Tag Number': '100-PT-001',
        'Tag Status': 'DELETED',
        'Equipment Name': 'PT-001-EQ',
    }])
    merged, report = reader.merge_mdb_allocation(alloc_df, mdb_df)
    # Deleted MDB record excluded — allocation tag appears as allocation-only
    assert '100-PT-001' in report['allocation_only_tags']
    assert '100-PT-001' in [str(t) for t in report['deleted_mdb_tags']]

def test_unmatched_mdb_tags_reported():
    reader = ExcelReader()
    alloc_df = pd.DataFrame([{'Tag': 'A-001', 'IO': 'AI', 'Status': 'Allocated'}])
    mdb_df = pd.DataFrame([{
        'Tag Number': 'B-999',   # not in allocation
        'Equipment Name': 'EQ',
    }])
    merged, report = reader.merge_mdb_allocation(alloc_df, mdb_df)
    assert 'B-999' in [str(t) for t in report['active_unmatched_mdb_tags']]
    assert 'A-001' in report['allocation_only_tags']

def test_error_ordering_not_weakened_by_criticality():
    """An error finding must remain an error regardless of signal criticality tier."""
    clf = CriticalityClassifier()
    result = clf.classify({'Tag': 'MISC-001', 'Process_Function': ''})
    assert result.tier == 'Unassessed'
    # The criticality tier should never downgrade an error severity.
    # This is a design assertion — no code path changes severity based on criticality.
    # Verify the tier ordering constant: Unassessed has the lowest priority number.
    from core.criticality_classifier import CRITICALITY_TIERS
    assert CRITICALITY_TIERS.index('Unassessed') == len(CRITICALITY_TIERS) - 1

def test_add_override_validates_tier():
    clf = CriticalityClassifier()
    with pytest.raises(ValueError):
        clf.add_override('TAG-001', 'P99 Invalid Tier')

def test_p1_never_inferred_only_confirmed():
    """P1 Safety/Protection can only come from explicit override, never from inference rules."""
    clf = CriticalityClassifier()
    # Even with a process function that sounds safety-related, default rules must not infer P1
    result = clf.classify({'Tag': 'PSH-001', 'Process_Function': 'safety shutdown', 'Risk_Area': 'SIS'})
    # Risk_Area and 'safety' in process function must not produce P1 inferred
    assert result.tier != 'P1 Safety/Protection'
    assert result.status != 'confirmed'  # not confirmed either (no override)
