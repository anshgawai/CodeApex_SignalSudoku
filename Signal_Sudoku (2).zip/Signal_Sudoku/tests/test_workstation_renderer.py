from types import SimpleNamespace

import pandas as pd

from services.workstation_renderer import WorkstationRenderer


def _render(rows, findings=()):
    allocation_df = pd.DataFrame(rows)
    return WorkstationRenderer().render_workstation(
        allocation_df=allocation_df,
        hardware_df=pd.DataFrame(),
        validation_findings=list(findings),
        tq_list=[],
        statistics={
            'total_signals': len(rows),
            'allocated': sum(row['Status'] == 'Allocated' for row in rows),
            'unallocated': sum(row['Status'] != 'Allocated' for row in rows),
            'cabinets': 1,
        },
    )


def _row(tag, status='Allocated'):
    return {
        'Tag': tag,
        'IO': 'AI',
        'Cable': 'C-1',
        'Pair': '1',
        'Group': 'G-1',
        'Cabinet': 'CAB-1',
        'CIOC': 'CIOC-1',
        'Baseplate': 'BP-1',
        'CHARM': 'CH-01',
        'CHARM_Type': 'AI CHARM (HART)',
        'Status': status,
        'Validation_Status': '',
        'Notes': '',
        'Segregation': 'A',
    }


def test_allocated_signal_with_cable_grouping_warning_stays_out_of_conflicts():
    warning = SimpleNamespace(
        finding_id='VAL-0001',
        severity='warning',
        rule_name='cable_grouping',
        affected_item='C-1',
        explanation="Cable 'C-1' is spread across 2 baseplates.",
        suggested_action='Keep cable signals together where possible.',
    )

    rendered = _render([_row('T-1')], [warning])

    assert 'data-status="allocated"' in rendered
    assert '<span>ALLOCATED</span>' in rendered
    assert 'WARNING ℹ</button>' in rendered
    assert 'class="filter-pill' in rendered
    assert 'data-status="conflict"' not in rendered


def test_allocated_signal_with_error_is_marked_as_conflict():
    error = SimpleNamespace(
        finding_id='VAL-0002',
        severity='error',
        rule_name='charm_type_mapping',
        affected_item='T-1',
        explanation="Signal 'T-1' has an incompatible CHARM type.",
        suggested_action='Review the classification mapping.',
    )

    rendered = _render([_row('T-1')], [error])

    assert 'data-status="conflict"' in rendered
    assert 'CONFLICT ℹ</span></button>' in rendered


def test_unallocated_signal_keeps_unallocated_status_and_filter():
    rendered = _render([_row('T-2', status='Unallocated')])

    assert 'data-status="unallocated"' in rendered
    assert 'UNALLOCATED ℹ</span></button>' in rendered
    assert 'data-status="conflict"' not in rendered


def test_workstation_uses_valid_dark_background_classes():
    rendered = _render([_row('T-1')])

    assert 'dark:bg-slate-850' not in rendered
    assert 'h-8 bg-white dark:bg-slate-800 border-b' in rendered
