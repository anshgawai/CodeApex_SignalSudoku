from pathlib import Path
from io import BytesIO
import hashlib
import json
import pandas as pd
import streamlit as st
from core.allocation_engine import AllocationEngine
from core.input_validation import InputValidator
from core.rule_validator import RuleValidator
from core.report_generator import ReportGenerator
from core.tq_generator import TQGenerator, TechnicalQuery
from core.tq_explainer import get_category_info, lookup_allocation_status, find_related_tqs, explain_tq
from core.revision_comparator import RevisionComparator
from core.revision_workflow import RevisionWorkflow
from services.configuration_service import ConfigurationService
from services.excel_reader import ExcelReader
from services.excel_exporter import ExcelExporter
from services.workstation_renderer import WorkstationRenderer
from core.criticality_classifier import CriticalityClassifier
import streamlit.components.v1 as components
from ui_theme import inject_theme

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title='Signal Sudoku', page_icon='', layout='wide')
inject_theme()
st.title('Signal Sudoku')
st.caption(
    'Industrial I/O signal allocation • Engineering-assistance prototype • '
    'Generated allocations require review by a qualified engineer.'
)


@st.cache_data
def read_excel_bytes(data):
    return pd.read_excel(BytesIO(data), dtype=str).fillna('')


def frame_from_upload(upload):
    if upload is None:
        return None
    return pd.read_excel(BytesIO(upload.getvalue()), dtype=str).fillna('')


def dataframe_fingerprint(df: pd.DataFrame) -> str:
    """Stable content hash so we can detect Excel/source changes."""
    if df is None or df.empty:
        return 'empty'
    payload = df.fillna('').astype(str).to_csv(index=False).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()


def clear_allocation_state():
    """Drop cached allocation/workstation results when the source workbook changes."""
    for key in ('allocation', 'revision_session', 'proposed_revision', '_ws_view_hash'):
        st.session_state.pop(key, None)


def mark_source_changed(had_results: bool):
    """Remember that Excel changed so we can rebuild the workstation allocation.

    Clearing alone left the UI on a stale iframe (or an empty results section)
    until the user clicked Allocate again — so we queue an automatic realloc.
    """
    clear_allocation_state()
    # Comment: only auto-rerun if the user already had results; first open
    # should still require an explicit Allocate click.
    if had_results:
        st.session_state['_pending_realloc'] = True


def build_tqs(input_findings, allocation_result):
    tqs = TQGenerator().generate_from_validation(input_findings)
    for idx, item in enumerate(allocation_result.tq_items, 1):
        tqs.append(TechnicalQuery(
            tq_id=f'TQ-ALLOC-{idx:04d}',
            affected_item=item['affected_item'],
            category=item['category'],
            description=item['description'],
            reason=item['reason'],
            information_needed='Confirm signal details, constraints, or available hardware.',
            suggested_action='Review the signal and project rules, then rerun allocation.',
            priority='High',
        ))
    return tqs


def run_allocation(normal_df, rules_dict, input_findings, source_fp, source_label, workflow_svc):
    """Allocate from the current Excel frame and store results for the workstation.

    Comment: centralised so manual Allocate and Excel-change auto-realloc share
    the same path — otherwise the workstation could keep a prior sheet's slots.
    """
    result = AllocationEngine(rules_dict).allocate(normal_df)
    findings = RuleValidator(rules_dict).validate(result)
    tqs = build_tqs(input_findings, result)
    session = workflow_svc.start_from_allocation(
        df=normal_df,
        rules=rules_dict,
        allocation_result=result,
        validation_findings=findings,
        input_findings=input_findings,
        tqs=tqs,
    )
    st.session_state['allocation'] = {
        'result': result,
        'findings': findings,
        'tqs': tqs,
        'df': normal_df,
        'rules': rules_dict,
        'input_findings': input_findings,
        'source_fp': source_fp,
        'source_label': source_label,
    }
    st.session_state['revision_session'] = session
    # Comment: proposed revisions are tied to the previous Excel allocation.
    st.session_state.pop('proposed_revision', None)
    st.session_state.pop('_ws_view_hash', None)
    st.session_state.pop('_pending_realloc', None)
    # Clear TQ selection state so the explanation panel resets for the new allocation.
    st.session_state.pop('selected_tq_id', None)
    st.session_state.pop('tq_select', None)
    st.session_state.pop('_last_tq_table_rows', None)
    st.session_state.pop('tq_table', None)


config = ConfigurationService(str(ROOT / 'config'))
rules = config.get_rules()
reader = ExcelReader()
reporter = ReportGenerator()
exporter = ExcelExporter()
workflow = RevisionWorkflow()
comparator = RevisionComparator()
workstation_renderer = WorkstationRenderer()

with st.sidebar:
    st.header('Project rules')
    st.caption('Changes apply to this run. Save them to reuse them next time.')
    rules['charms_per_baseplate'] = st.number_input(
        'CHARMs per baseplate', min_value=1, max_value=64, value=int(rules['charms_per_baseplate'])
    )
    rules['baseplates_per_cioc'] = st.number_input(
        'Baseplates per CIOC', min_value=1, max_value=32, value=int(rules['baseplates_per_cioc'])
    )
    rules['ciocs_per_cabinet'] = st.number_input(
        'CIOCs per cabinet', min_value=1, max_value=16, value=int(rules['ciocs_per_cabinet'])
    )
    rules['keep_groups_together'] = st.checkbox(
        'Keep groups in same cabinet', value=rules['keep_groups_together']
    )
    rules['enforce_segregation'] = st.checkbox(
        'Keep segregation classes on separate CIOCs', value=rules['enforce_segregation']
    )
    rules['keep_cables_together'] = st.checkbox(
        'Keep cable signals on same baseplate where possible', value=rules['keep_cables_together']
    )
    rules['maintain_pair_order'] = st.checkbox(
        'Order signals by cable pair', value=rules['maintain_pair_order']
    )
    rules['reserve_spare_capacity'] = st.checkbox(
        'Reserve spare capacity', value=rules['reserve_spare_capacity']
    )
    if rules['reserve_spare_capacity']:
        rules['spare_percentage'] = st.slider(
            'Spare capacity (%)', 0.0, 50.0, float(rules.get('spare_percentage', 10.0)), step=1.0
        )
    rules['default_do_subtype'] = st.selectbox(
        'Default DO hardware',
        ['normal', 'solenoid', 'relay'],
        index=['normal', 'solenoid', 'relay'].index(rules.get('default_do_subtype', 'normal')),
    )
    if st.button('Save rules', use_container_width=True):
        errors = config.validate_rules(rules)
        if errors:
            st.error('\n'.join(errors))
        else:
            config.save_rules(rules)
            st.success('Rules saved.')
    if st.button('Reset defaults', use_container_width=True):
        config.reset_to_defaults()
        st.rerun()

left, right = st.columns([3, 2])
with left:
    st.subheader('1. Upload File')
    uploaded_file = st.file_uploader('Upload I/O MDB Excel file', type=['xlsx', 'xlsm', 'xls'], key='mdb_upload')

    # When a new workbook is uploaded, prefer it over the sample checkbox
    upload_token = None
    if uploaded_file is not None:
        upload_bytes = uploaded_file.getvalue()
        upload_token = (
            uploaded_file.name,
            len(upload_bytes),
            hashlib.sha256(upload_bytes).hexdigest()
        )

    if upload_token is not None and st.session_state.get('_upload_token') != upload_token:
        had_results = 'allocation' in st.session_state
        st.session_state['_upload_token'] = upload_token
        st.session_state['use_sample'] = False
        mark_source_changed(had_results)

    use_sample = st.checkbox(
        'Use generated synthetic sample data instead',
        value=(uploaded_file is None),
        key='use_sample',
    )
    sample_alloc_path = ROOT / 'sample_data' / 'Sample_IO_Allocation_VIT_v2 1 (1).xlsx'
    sample_mdb_path = ROOT / 'sample_data' / 'Sample_IO_MDB_VIT_v2 1.xlsx'

    df = None
    merge_report = None
    source_label = ''

    if use_sample:
        if not sample_alloc_path.exists() or not sample_mdb_path.exists():
            st.info('Sample files not found. Using default sample data.')
            sample_path = ROOT / 'sample_data' / 'sample_io_mdb_clean.xlsx'
            if sample_path.exists():
                df = pd.read_excel(sample_path, dtype=str).fillna('')
                source_label = sample_path.name
            else:
                st.warning('No sample data found.')
        else:
            alloc_df = pd.read_excel(sample_alloc_path, sheet_name='IO Assignment', dtype=str).fillna('')
            mdb_df = pd.read_excel(sample_mdb_path, sheet_name='MDB-1', dtype=str).fillna('')
            df, merge_report = reader.merge_mdb_allocation(alloc_df, mdb_df)
            source_label = f"{sample_alloc_path.name} + {sample_mdb_path.name}"
    else:
        if uploaded_file is not None:
            try:
                xl = pd.ExcelFile(BytesIO(uploaded_file.getvalue()), engine='openpyxl')
                sheet_names = xl.sheet_names
                if 'IO Assignment' in sheet_names and 'MDB-1' in sheet_names:
                    alloc_df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name='IO Assignment', dtype=str).fillna('')
                    mdb_df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name='MDB-1', dtype=str).fillna('')
                    df, merge_report = reader.merge_mdb_allocation(alloc_df, mdb_df)
                    source_label = f"{uploaded_file.name} (IO Assignment + MDB-1)"
                elif 'MDB-1' in sheet_names:
                    df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name='MDB-1', dtype=str).fillna('')
                    source_label = f"{uploaded_file.name} (MDB-1)"
                elif 'IO_MDB' in sheet_names:
                    df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name='IO_MDB', dtype=str).fillna('')
                    source_label = f"{uploaded_file.name} (IO_MDB)"
                elif 'IO Assignment' in sheet_names:
                    df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name='IO Assignment', dtype=str).fillna('')
                    source_label = f"{uploaded_file.name} (IO Assignment)"
                else:
                    df = pd.read_excel(BytesIO(uploaded_file.getvalue()), sheet_name=sheet_names[0], dtype=str).fillna('')
                    source_label = f"{uploaded_file.name} ({sheet_names[0]})"
            except Exception:
                df = pd.read_excel(BytesIO(uploaded_file.getvalue()), dtype=str).fillna('')
                source_label = uploaded_file.name
        else:
            st.warning('Upload an I/O MDB file, or enable the synthetic sample checkbox.')

with right:
    st.subheader('2. Input preview')
    if df is not None:
        st.metric('Input signals', len(df))
        st.caption(f'Source: {source_label}')
        if merge_report:
            with st.expander('MDB Merge Report'):
                st.write(f"Matched: {merge_report['matched_count']}")
                st.write(f"Allocation-only tags: {len(merge_report['allocation_only_tags'])}")
                st.write(f"Unmatched MDB tags: {len(merge_report['active_unmatched_mdb_tags'])}")
                if merge_report['deleted_mdb_tags']:
                    st.write(f"Deleted MDB tags (excluded): {len(merge_report['deleted_mdb_tags'])}")
        st.dataframe(df.head(10), use_container_width=True, hide_index=True)

# No active workbook → drop any prior workstation/allocation so the UI cannot
# keep showing results from a previous Excel sheet.
if df is None and 'allocation' in st.session_state:
    clear_allocation_state()
    st.session_state.pop('_source_fp', None)
    st.session_state.pop('_pending_realloc', None)

if df is not None:
    validator = InputValidator()
    normal = validator.normalize_dataframe(df)
    # Comment: hash raw + normalised so either preview or model-field edits count.
    source_fp = dataframe_fingerprint(normal) + '|' + dataframe_fingerprint(df)

    # Invalidate / rebuild workstation when the active sheet content changes
    # (new upload, toggled sample, or edited regenerated sample on disk).
    if st.session_state.get('_source_fp') != source_fp:
        prior = st.session_state.get('_source_fp')
        had_results = 'allocation' in st.session_state
        st.session_state['_source_fp'] = source_fp
        if prior is not None:
            # Comment: sheet content drifted — queue realloc so workstation
            # tracks the new Excel instead of keeping old cabinet/CHARM slots.
            mark_source_changed(had_results)

    input_findings, fatal = validator.validate(normal)
    with st.expander(f'Input checks ({len(input_findings)} findings)', expanded=bool(fatal)):
        if input_findings:
            st.dataframe(
                pd.DataFrame([f.__dict__ for f in input_findings]),
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.success('No input validation findings.')

    # Comment: Allocate button OR automatic realloc after Excel change.
    # SIGNALSUDOKU_UIUX: BEGIN
    # Defect: 'Allocate signals' button text appeared in black font on a dark purple background.
    # Root cause: Paragraph text inside Streamlit buttons inherits global typography colors without an explicit key hook.
    # Fix: Added key='allocate_signals_btn' for explicit styling.
    # Unchanged: Allocation triggering, pending reallocation check, and engine execution remain identical.
    manual_allocate = st.button(
        'Allocate signals',
        type='primary',
        use_container_width=True,
        key='allocate_signals_btn',
    )
    # SIGNALSUDOKU_UIUX: END
    pending_realloc = bool(st.session_state.get('_pending_realloc'))
    if pending_realloc and not fatal:
        st.info('Excel sheet changed — refreshing allocation so the workstation matches the new data.')

    if manual_allocate or (pending_realloc and not fatal):
        errors = config.validate_rules(rules)
        if errors:
            st.error('Fix rule settings first: ' + '; '.join(errors))
            st.session_state.pop('_pending_realloc', None)
        else:
            try:
                run_allocation(normal, rules, input_findings, source_fp, source_label, workflow)
                st.rerun()
            except Exception as exc:
                st.session_state.pop('_pending_realloc', None)
                st.error(f'Allocation failed: {exc}')

if 'allocation' in st.session_state:
    saved = st.session_state['allocation']
    # Comment: never paint the workstation from a sheet that no longer matches
    # the active Excel fingerprint (guards against missed invalidation races).
    if df is not None:
        live_fp = dataframe_fingerprint(InputValidator().normalize_dataframe(df)) + '|' + dataframe_fingerprint(df)
        if saved.get('source_fp') and saved.get('source_fp') != live_fp:
            mark_source_changed(True)
            st.warning('Source Excel no longer matches the displayed allocation — refreshing…')
            st.rerun()

    result = saved['result']
    findings = saved['findings']
    tqs = saved['tqs']
    rules_used = saved['rules']
    input_findings = saved.get('input_findings', [])
    session = st.session_state.get('revision_session')

    st.divider()
    st.subheader('3. Results')
    # NOTE (Allocation Count Fix): Reconcile Results metrics so that Signals == Allocated + Unallocated.
    # Total signals accounts for all input rows (e.g. 83), allocated signals represents successfully
    # placed slots (81), and unallocated signals accounts for failed/duplicate/invalid rows (2).
    m = result.statistics
    cols = st.columns(6)
    cols[0].metric('Signals', m['total_signals'], help='Total input signal rows processed')
    cols[1].metric('Allocated', m['allocated'], help='Signals successfully allocated to CHARM slots')
    cols[2].metric('Unallocated', m['unallocated'], help='Signals that could not be allocated')
    cols[3].metric('Technical Queries (TQs)', len(tqs), help='Total technical queries generated for engineering review')
    cols[4].metric('Cabinets', m['cabinets'])
    cols[5].metric('CIOCs', m['ciocs'])

    # Display clear breakdown when distinct input rows and unique signal tags differ due to duplicates
    if m.get('unique_signals') and m['unique_signals'] < m['total_signals']:
        dup_count = m['total_signals'] - m['unique_signals']
        st.caption(
            f"Note: {m['total_signals']} input rows ({m['unique_signals']} unique tags). "
            f"{m['allocated']} allocated, {m['unallocated']} unallocated "
            f"({dup_count} duplicate tag row{'s' if dup_count > 1 else ''}, "
            f"{m['unallocated'] - dup_count} unplaced)."
        )

    if m['unallocated']:
        st.warning(
            f"{m['unallocated']} signal(s) could not be allocated. "
            'Each has a technical query; review before treating this as complete.'
        )
    else:
        st.success(
            'Every signal received a slot. Review validation findings before accepting the result.'
        )

    allocation_df = reporter.generate_allocation_table(result)
    validation_df = reporter.generate_validation_report(findings, allocation_result=result)

    # MDB metadata merge and criticality enrichment
    mdb_df_for_merge = st.session_state.get('mdb_df')
    mdb_merge_report = None
    if mdb_df_for_merge is not None and not mdb_df_for_merge.empty:
        try:
            allocation_df, mdb_merge_report = reader.merge_mdb_allocation(allocation_df, mdb_df_for_merge)
        except Exception as exc:
            st.warning(f'MDB merge failed: {exc}')

    if mdb_merge_report:
        with st.expander(f'MDB merge report (matched: {mdb_merge_report["matched_count"]})', expanded=False):
            if mdb_merge_report['allocation_only_tags']:
                st.warning(f'{len(mdb_merge_report["allocation_only_tags"])} allocation-only tags (no MDB record): ' + ', '.join(str(t) for t in mdb_merge_report["allocation_only_tags"][:20]))
            if mdb_merge_report['active_unmatched_mdb_tags']:
                st.warning(f'{len(mdb_merge_report["active_unmatched_mdb_tags"])} active MDB tags not in allocation: ' + ', '.join(str(t) for t in mdb_merge_report["active_unmatched_mdb_tags"][:20]))
            if mdb_merge_report['deleted_mdb_tags']:
                st.info(f'{len(mdb_merge_report["deleted_mdb_tags"])} DELETED MDB records excluded from matching.')
    tq_df = reporter.generate_tq_report(tqs)
    hardware_df = reporter.generate_hardware_summary(result)
    config_df = reporter.generate_configuration_report(rules_used)

    # ----- 4. Engineering Workstation -----
    st.subheader('4. Engineering Workstation')

    # Prefer proposed revision in the workstation once rule changes are approved,
    # so the view tracks the latest allocation — not the stale original Excel run.
    proposed = st.session_state.get('proposed_revision')
    ws_allocation_df = allocation_df
    ws_hardware_df = hardware_df
    ws_findings = findings
    ws_tqs = tqs
    ws_stats = m
    ws_rules = rules_used
    if proposed and proposed.get('session') and proposed['session'].revised_result is not None:
        upd = proposed['session']
        ws_allocation_df = proposed['allocation_df']
        ws_hardware_df = proposed['hardware_df']
        ws_findings = upd.revised_findings or []
        ws_tqs = upd.revised_tqs or []
        ws_stats = upd.revised_result.statistics
        ws_rules = upd.approved_rules or rules_used
        st.caption('Showing **proposed revision** allocation in the workstation.')
    else:
        st.caption(
            f"Bound to current allocation from **{saved.get('source_label', 'workbook')}**. "
            'Upload a different Excel file (or toggle sample) and click **Allocate signals** to refresh.'
        )

    active_filename = saved.get(
        'source_label',
        uploaded_file.name if uploaded_file is not None else (
            'sample_io_mdb_clean.xlsx' if use_sample else 'io_signals.xlsx'
        ),
    )

    workstation_html = workstation_renderer.render_workstation(
        allocation_df=ws_allocation_df,
        hardware_df=ws_hardware_df,
        validation_findings=ws_findings,
        tq_list=ws_tqs,
        statistics=ws_stats,
        filename=active_filename,
        project_id=str(ws_rules.get('project_id', 'PRJ-8420-TX-REF-03')),
    )

    # Streamlit's components.html iframe often keeps stale content unless remounted.
    # Bust the cache whenever allocation/source content changes.
    ws_view_hash = hashlib.sha256(
        (
            dataframe_fingerprint(ws_allocation_df)
            + '|'
            + json.dumps(ws_stats, sort_keys=True, default=str)
            + '|'
            + active_filename
        ).encode('utf-8')
    ).hexdigest()[:16]
    workstation_html = workstation_html.replace(
        '<html lang="en"',
        f'<html lang="en" data-ws-rev="{ws_view_hash}"',
        1,
    )
    st.session_state['_ws_view_hash'] = ws_view_hash
    # Height alternates by content hash so Streamlit remounts the iframe when
    # Excel/allocation data changes (components.html otherwise keeps a stale view).
    ws_height = 820 + (int(ws_view_hash[:2], 16) % 2)
    components.html(workstation_html, height=ws_height, scrolling=True)

    # ----- 5. Detailed Reports & Workflow -----
    st.subheader('5. Detailed Reports & Workflow')
    tabs = st.tabs([
        'Allocation Table',
        'Rule checks',
        f'Technical queries ({len(tqs)})',
        'Hardware summary',
        'Rule Change Suggestions',
        'Proposed revision',
        'Revision comparison',
    ])

    with tabs[0]:
        # Show criticality/alarm priority columns if MDB was merged
        display_cols = list(allocation_df.columns)
        priority_cols = ['Criticality', 'Criticality_Status', 'Alarm_Priority']
        available_priority_cols = [c for c in priority_cols if c in display_cols]
        if available_priority_cols:
            st.caption('Criticality and Alarm Priority sourced from MDB metadata. '
                       '"inferred" status requires engineer review. '
                       'Criticality may change sort order but never weakens error severity.')
        st.dataframe(allocation_df, use_container_width=True, hide_index=True)
    with tabs[1]:
        if session and session.analysis:
            summary = session.analysis.summary
            c1, c2, c3, c4 = st.columns(4)
            c1.metric('Source data', summary.get('source_data', 0))
            c2.metric('Assignment', summary.get('assignment', 0))
            c3.metric('Configurable rule', summary.get('configurable_rule', 0))
            c4.metric('Hard constraint', summary.get('hard_constraint', 0))
            problems_df = reporter.generate_problems_report(session.analysis.problems)
            if not problems_df.empty:
                st.write('Classified conflict findings:')
                st.dataframe(problems_df, use_container_width=True, hide_index=True)

        if validation_df.empty:
            st.success('No rule violations found by the current validator.')
        else:
            st.write('Full rule validation report:')
            st.dataframe(validation_df, use_container_width=True, hide_index=True)
    with tabs[2]:
        if tq_df.empty:
            st.info('No technical queries generated.')
        else:
            tq_left, tq_right = st.columns([3, 2])
            tq_ids = [tq.tq_id for tq in tqs]
            tq_options = {
                f"{tq.tq_id} — {tq.affected_item or 'Unknown'} ({tq.category})": tq.tq_id
                for tq in tqs
            }
            tq_id_to_label = {v: k for k, v in tq_options.items()}
            label_list = list(tq_options.keys())

            # NOTE (TQ Explanations - Selection Sync): Two-way synchronization between table clicks and selector.
            # If a user clicks a row in the dataframe, update the selected TQ and synchronize the dropdown widget.
            table_state = st.session_state.get('tq_table', {})
            table_rows = []
            if hasattr(table_state, 'selection') and hasattr(table_state.selection, 'rows'):
                table_rows = list(table_state.selection.rows)
            elif isinstance(table_state, dict):
                table_rows = list(table_state.get('selection', {}).get('rows', []))

            last_rows = st.session_state.get('_last_tq_table_rows', [])
            if table_rows and table_rows != last_rows:
                st.session_state['_last_tq_table_rows'] = table_rows
                clicked_idx = table_rows[0]
                if 0 <= clicked_idx < len(tqs):
                    clicked_id = tqs[clicked_idx].tq_id
                    st.session_state['selected_tq_id'] = clicked_id
                    st.session_state['tq_select'] = tq_id_to_label.get(clicked_id, label_list[0])

            # Ensure an active selection exists so explanations remain visible from the start
            if 'selected_tq_id' not in st.session_state or st.session_state['selected_tq_id'] not in tq_ids:
                st.session_state['selected_tq_id'] = tq_ids[0]
                st.session_state['tq_select'] = tq_id_to_label.get(tq_ids[0], label_list[0])

            with tq_left:
                st.markdown('##### Technical Queries')
                cur_id = st.session_state.get('selected_tq_id', tq_ids[0])
                cur_label = tq_id_to_label.get(cur_id, label_list[0])
                cur_index = label_list.index(cur_label) if cur_label in label_list else 0

                selected_label = st.selectbox(
                    'Select a TQ to see its explanation',
                    options=label_list,
                    index=cur_index,
                    key='tq_select',
                )
                if selected_label in tq_options:
                    chosen_id = tq_options[selected_label]
                    if chosen_id != st.session_state.get('selected_tq_id'):
                        st.session_state['selected_tq_id'] = chosen_id

                df_selection = st.dataframe(
                    tq_df,
                    use_container_width=True,
                    hide_index=True,
                    on_select='rerun',
                    selection_mode='single-row',
                    key='tq_table',
                )

                # Check if click just occurred on the dataframe in this run
                new_table_rows = []
                if hasattr(df_selection, 'selection') and hasattr(df_selection.selection, 'rows'):
                    new_table_rows = list(df_selection.selection.rows)
                elif isinstance(df_selection, dict):
                    new_table_rows = list(df_selection.get('selection', {}).get('rows', []))

                if new_table_rows and new_table_rows != st.session_state.get('_last_tq_table_rows', []):
                    st.session_state['_last_tq_table_rows'] = new_table_rows
                    c_idx = new_table_rows[0]
                    if 0 <= c_idx < len(tqs):
                        c_id = tqs[c_idx].tq_id
                        if c_id != st.session_state.get('selected_tq_id'):
                            st.session_state['selected_tq_id'] = c_id
                            st.session_state['tq_select'] = tq_id_to_label.get(c_id, label_list[0])
                            st.rerun()

            with tq_right:
                st.markdown('##### TQ Explanation')
                # NOTE (TQ Explanations - Concise Display):
                # Card-style render: badge, signal tag, issue, impact, fix, status, related TQs.
                active_id = st.session_state.get('selected_tq_id', tq_ids[0])
                sel_tq = next((t for t in tqs if t.tq_id == active_id), tqs[0] if tqs else None)
                if sel_tq is not None:
                    explanation = explain_tq(sel_tq, result, tqs)
                    cat_info = get_category_info(sel_tq.category)
                    badge = cat_info['classification_label']
                    plain_name = cat_info['plain_name']

                    # --- Compact card ---
                    st.markdown(
                        f"**{badge} — {plain_name}**  \n"
                        f"Signal: {explanation['affected_item']}"
                    )
                    st.markdown(
                        f"**Issue:** {explanation['meaning']}  \n"
                        f"**Why flagged:** {explanation['why_flagged']}  \n"
                        f"**Impact:** {explanation['impact']}"
                    )
                    st.info(f" **Fix:** {explanation['recommended_action']}", icon=None)
                    # Allocation status badge
                    alloc_str = explanation['allocation_status']
                    if alloc_str.startswith('Allocated'):
                        st.success(f"**Status:** {alloc_str}")
                    elif alloc_str.startswith('Unallocated'):
                        st.error(f"**Status:** {alloc_str}")
                    else:
                        st.warning(f"**Status:** {alloc_str}")
                    # Related TQs
                    if explanation['related_tqs']:
                        with st.expander(f"Related TQs ({len(explanation['related_tqs'])})"):
                            for r in explanation['related_tqs']:
                                st.markdown(f"- `{r['tq_id']}` · *{r['category']}* — {r['description']}")
    with tabs[3]:
        st.dataframe(hardware_df, use_container_width=True, hide_index=True)

    with tabs[4]:
        st.write(
            'Review permissible configurable preference changes. '
            'Hard constraints (segregation, CHARM mapping, physical capacity invariants) '
            'are never suggested for weakening. Selected changes are **not** applied until you approve.'
        )
        if not session:
            st.info('Allocate signals first to generate suggestions.')
        elif session.analysis and session.analysis.summary.get('fully_valid'):
            st.success('Allocation is already valid under current rules — no rule changes needed.')
        else:
            sug_result = session.suggestion_result
            if sug_result and sug_result.no_solution_reason and not session.suggestions:
                st.warning(sug_result.no_solution_reason)
                if sug_result.hard_blockers:
                    st.write('Hard constraint blockers:')
                    st.dataframe(
                        reporter.generate_problems_report(sug_result.hard_blockers),
                        use_container_width=True,
                        hide_index=True,
                    )
            if session.suggestions:
                sug_rows = []
                for s in session.suggestions:
                    sug_rows.append({
                        'ID': s.suggestion_id,
                        'Rule': s.rule_key,
                        'Current': str(s.current_value),
                        'Proposed': str(s.proposed_value),
                        'Conflict': s.conflict_resolved,
                        'Expected impact': s.expected_impact,
                        'Warnings': '; '.join(s.warnings),
                    })
                st.dataframe(pd.DataFrame(sug_rows), use_container_width=True, hide_index=True)

                selected = st.multiselect(
                    'Select suggestions to approve',
                    options=[s.suggestion_id for s in session.suggestions],
                    format_func=lambda sid: next(
                        (
                            f"{s.suggestion_id}: {s.rule_key} "
                            f"{s.current_value} → {s.proposed_value}"
                            for s in session.suggestions if s.suggestion_id == sid
                        ),
                        sid,
                    ),
                    key='selected_suggestions',
                )
                col_a, col_b = st.columns(2)
                with col_a:
                    if st.button(
                        'Approve selected & reallocate',
                        type='primary',
                        use_container_width=True,
                        disabled=not selected,
                    ):
                        try:
                            updated = workflow.approve_and_reallocate(
                                session, selected, input_findings=input_findings
                            )
                            st.session_state['revision_session'] = updated
                            # Build proposed export artefacts
                            rev_alloc_df = reporter.generate_allocation_table(updated.revised_result)
                            rev_val_df = reporter.generate_validation_report(updated.revised_findings, allocation_result=updated.revised_result)
                            rev_tq_df = reporter.generate_tq_report(updated.revised_tqs)
                            rev_hw_df = reporter.generate_hardware_summary(updated.revised_result)
                            rev_cfg_df = reporter.generate_configuration_report(updated.approved_rules)
                            rules_rows = workflow.rule_change_summary_rows(updated)
                            rules_df = reporter.generate_approved_rules_report(rules_rows)
                            summary_df = reporter.generate_change_summary_report(
                                workflow.change_summary_dict(updated)
                            )
                            cmp = comparator.compare_allocations(allocation_df, rev_alloc_df)
                            cmp_df = reporter.generate_allocation_comparison_report(cmp)
                            workbook = exporter.export_proposed_revision(
                                rev_alloc_df,
                                rev_val_df,
                                rev_tq_df,
                                rev_hw_df,
                                rev_cfg_df,
                                summary_df,
                                rules_df,
                                comparison_df=cmp_df,
                                is_fully_valid=updated.is_fully_valid,
                                is_diagnostic=not updated.is_fully_valid,
                            )
                            st.session_state['proposed_revision'] = {
                                'session': updated,
                                'allocation_df': rev_alloc_df,
                                'validation_df': rev_val_df,
                                'tq_df': rev_tq_df,
                                'hardware_df': rev_hw_df,
                                'config_df': rev_cfg_df,
                                'summary_df': summary_df,
                                'rules_df': rules_df,
                                'comparison': cmp,
                                'comparison_df': cmp_df,
                                'workbook': workbook.getvalue(),
                            }
                            st.rerun()
                        except Exception as exc:
                            st.error(f'Reallocation failed: {exc}')
                with col_b:
                    if st.button('Cancel (keep original rules)', use_container_width=True):
                        workflow.cancel(session)
                        st.session_state['revision_session'] = session
                        st.session_state.pop('proposed_revision', None)
                        st.info(
                            'Cancelled. Original rules and uploaded data are unchanged. '
                            'Sidebar project rules were not permanently overwritten.'
                        )

    with tabs[5]:
        proposed = st.session_state.get('proposed_revision')
        if not proposed:
            st.info(
                'Approve rule changes in **Rule Change Suggestions** to generate a proposed revision.'
            )
        else:
            upd = proposed['session']
            if upd.is_fully_valid:
                st.success(
                    'Proposed allocation satisfies hard constraints with no unallocated signals. '
                    'Still requires qualified engineering review.'
                )
            else:
                st.error(
                    'Proposed reallocation did not produce a fully valid result. '
                    'Remaining conflicts are shown below — reconsider suggestions or fix source data. '
                    'You may download a labelled diagnostic report (not a successful revision).'
                )

            rm = upd.revised_result.statistics
            rcols = st.columns(4)
            rcols[0].metric('Allocated', rm.get('allocated', 0))
            rcols[1].metric('Unallocated', rm.get('unallocated', 0))
            rcols[2].metric('Rule changes applied', len(upd.approved_suggestions))
            rcols[3].metric('Fully valid', 'Yes' if upd.is_fully_valid else 'No')

            st.write('Approved rule changes (session only — original config file unchanged):')
            st.dataframe(proposed['rules_df'], use_container_width=True, hide_index=True)
            st.write('Proposed allocation:')
            st.dataframe(proposed['allocation_df'], use_container_width=True, hide_index=True)
            if not proposed['validation_df'].empty:
                st.write('Remaining validation findings:')
                st.dataframe(proposed['validation_df'], use_container_width=True, hide_index=True)

            fname = (
                'signal_sudoku_proposed_revision.xlsx'
                if upd.is_fully_valid
                else 'signal_sudoku_diagnostic_report.xlsx'
            )
            st.download_button(
                'Download proposed revision workbook (.xlsx)'
                if upd.is_fully_valid
                else 'Download diagnostic report (.xlsx)',
                data=proposed['workbook'],
                file_name=fname,
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                type='primary',
            )

            st.write('Original vs proposed allocation comparison:')
            st.json(proposed['comparison'].summary)
            st.dataframe(proposed['comparison_df'], use_container_width=True, hide_index=True)
            cmp_book = exporter.export_revision_report(proposed['comparison_df'])
            st.download_button(
                'Download allocation comparison report (.xlsx)',
                data=cmp_book.getvalue(),
                file_name='signal_sudoku_allocation_comparison.xlsx',
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

    with tabs[6]:
        st.write(
            'Upload a later revision to compare signal tags and source fields '
            '(existing MDB-vs-MDB workflow).'
        )
        proposed = st.session_state.get('proposed_revision')
        if proposed:
            st.info(
                'A proposed revision is available. Use the **Proposed revision** tab to compare '
                'the original allocation with the automatically generated revision, '
                'or upload a separate Revision B file below.'
            )
        rev_upload = st.file_uploader(
            'Revision B Excel file', type=['xlsx', 'xlsm', 'xls'], key='revision_b'
        )
        if rev_upload:
            rev_b = frame_from_upload(rev_upload)
            rev_result = RevisionComparator().compare(
                saved['df'], InputValidator().normalize_dataframe(rev_b)
            )
            rev_rows = []
            for kind, changes in [
                ('Added', rev_result.added),
                ('Deleted', rev_result.deleted),
                ('Modified', rev_result.modified),
                ('Unchanged', rev_result.unchanged),
            ]:
                for change in changes:
                    rev_rows.append({
                        'Tag': change.tag,
                        'Change': kind,
                        'Changed fields': json.dumps(change.changed_fields, ensure_ascii=False),
                    })
            st.json(rev_result.summary)
            st.dataframe(pd.DataFrame(rev_rows), use_container_width=True, hide_index=True)
            mdb_cmp_df = reporter.generate_allocation_comparison_report(rev_result)
            mdb_book = exporter.export_revision_report(mdb_cmp_df)
            st.download_button(
                'Download MDB revision comparison (.xlsx)',
                data=mdb_book.getvalue(),
                file_name='signal_sudoku_mdb_revision_comparison.xlsx',
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

    workbook = exporter.export_allocation(
        allocation_df, validation_df, tq_df, hardware_df, config_df
    )
    st.download_button(
        'Download allocation workbook (.xlsx)',
        data=workbook.getvalue(),
        file_name='signal_sudoku_allocation.xlsx',
        mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        type='primary',
    )
else:
    st.info('Upload an Excel file or select the synthetic sample, then click **Allocate signals**.')
