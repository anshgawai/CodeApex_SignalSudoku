"""Excel file reading service for Signal Sudoku.

Reads I/O MDB workbooks, handles column mapping,
and prepares data for validation and allocation.
"""
import pandas as pd
import openpyxl
from typing import List, Dict, Optional, Tuple, Any, Union
from pathlib import Path
from io import BytesIO


# Known column aliases: canonical_name -> list of acceptable aliases (lowercase, stripped)
KNOWN_COLUMNS: Dict[str, List[str]] = {
    'Tag': ['tag', 'tag number', 'tag_number', 'tagno', 'tag no', 'instrument tag', 'tag name'],
    'IO': ['io', 'i/o', 'io_type', 'signal type', 'signal_type', 'iotype', 'io type', 'i/o type name'],
    'Cable': ['cable', 'cable no', 'cable_no', 'cable_id', 'cable number', 'cable_number', 'cableno', 'field cable no', 'multi-cable / cable', 'multipair cable no.'],
    'Pair': ['pair', 'pair no', 'pair_no', 'pair number', 'pair_number', 'pairno', 'field cable pair'],
    'Grp': ['grp', 'group', 'logical group', 'logical_group', 'process group', 'grp_id', 'io grouping'],
    'Seg': ['seg', 'segregation', 'seg class', 'seg_class', 'segregation class', 'segregation_class'],
    # New columns for MDB and Priority categorization
    'Equipment_Name': ['equipment name', 'equipment_name', 'equipment'],
    'Equipment_Description': ['equipment description', 'equipment_description', 'service', 'service description'],
    'Process_Function': ['process function type', 'process_function_type', 'process function'],
    'Instrument_Type': ['instrument type description', 'instrument type', 'instrument_type'],
    'Alarm_Priority': ['discrete alarm priority', 'discrete_alarm_priority', 'alarm priority'],
    'Tag_Status': ['tag status', 'tag_status', 'status'],
    'Risk_Area': ['risk area', 'risk_area'],
    'Voting': ['voting'],
}


class ExcelReader:
    """Service for reading and parsing I/O MDB Excel workbooks.

    Handles file path and BytesIO inputs, auto-detects column mappings,
    and provides preview/statistics for the Streamlit UI.
    """

    def get_sheet_names(self, file_path_or_buffer: Union[str, Path, BytesIO]) -> List[str]:
        """Return a list of sheet names in the workbook.

        Args:
            file_path_or_buffer: Path to the Excel file or a BytesIO buffer
                                 (e.g. from a Streamlit file uploader).

        Returns:
            List of sheet name strings.
        """
        if isinstance(file_path_or_buffer, BytesIO):
            file_path_or_buffer.seek(0)
        xl = pd.ExcelFile(file_path_or_buffer, engine='openpyxl')
        return xl.sheet_names

    def read_sheet(
        self,
        file_path_or_buffer: Union[str, Path, BytesIO],
        sheet_name: Optional[str] = None,
    ) -> pd.DataFrame:
        """Read the specified sheet (or the first sheet) into a DataFrame.

        Args:
            file_path_or_buffer: Path to the Excel file or a BytesIO buffer.
            sheet_name: Name of the sheet to read.  ``None`` reads the first
                        sheet.

        Returns:
            A pandas DataFrame with the sheet data.
        """
        if isinstance(file_path_or_buffer, BytesIO):
            file_path_or_buffer.seek(0)

        kwargs: Dict[str, Any] = {
            'engine': 'openpyxl',
            'dtype': str,  # read everything as strings initially to avoid data loss
        }
        if sheet_name is not None:
            kwargs['sheet_name'] = sheet_name
        else:
            kwargs['sheet_name'] = 0  # first sheet

        df = pd.read_excel(file_path_or_buffer, **kwargs)
        # Strip whitespace from column headers
        df.columns = [str(c).strip() for c in df.columns]
        return df

    def detect_columns(self, df: pd.DataFrame) -> Dict[str, str]:
        """Auto-detect column mapping by matching known column names.

        Matching is case-insensitive and whitespace-tolerant.

        Args:
            df: DataFrame whose columns should be inspected.

        Returns:
            Mapping of canonical column name → actual column name found in *df*.
            Only columns that were successfully matched are included.
        """
        mapping: Dict[str, str] = {}
        actual_columns = list(df.columns)

        for canonical, aliases in KNOWN_COLUMNS.items():
            for actual in actual_columns:
                normalised = actual.strip().lower().replace('_', ' ').replace('-', ' ')
                # Also try collapsing multiple spaces
                normalised_compact = ' '.join(normalised.split())
                for alias in aliases:
                    alias_norm = alias.strip().lower().replace('_', ' ').replace('-', ' ')
                    alias_compact = ' '.join(alias_norm.split())
                    if normalised_compact == alias_compact:
                        mapping[canonical] = actual
                        break
                if canonical in mapping:
                    break

        return mapping

    def apply_column_mapping(self, df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
        """Rename columns based on a mapping dict, returning a new DataFrame.

        Args:
            df: Source DataFrame.
            mapping: ``{canonical_name: actual_column_name}`` as produced by
                     :py:meth:`detect_columns`.

        Returns:
            A *copy* of *df* with matched columns renamed to their canonical
            names.
        """
        # Build the inverse: actual -> canonical
        rename_map = {actual: canonical for canonical, actual in mapping.items()}
        return df.rename(columns=rename_map).copy()

    def get_preview(self, df: pd.DataFrame, n_rows: int = 20) -> pd.DataFrame:
        """Return the first *n_rows* of the DataFrame for UI preview.

        Args:
            df: Source DataFrame.
            n_rows: Number of rows to include (default 20).

        Returns:
            A DataFrame with at most *n_rows* rows.
        """
        return df.head(n_rows).copy()

    def get_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Compute summary statistics about the I/O data.

        Expects a DataFrame with canonical column names (i.e. after
        :py:meth:`apply_column_mapping` has been applied).

        Args:
            df: Source DataFrame with standardised column names.

        Returns:
            Dictionary with keys:
            - ``total_rows``: total number of rows
            - ``unique_tags``: number of unique non-null Tag values
            - ``signal_types``: dict mapping each IO type to its count
            - ``cables``: number of unique non-null Cable values
            - ``groups``: number of unique non-null Grp values
        """
        stats: Dict[str, Any] = {
            'total_rows': len(df),
            'unique_tags': 0,
            'signal_types': {},
            'cables': 0,
            'groups': 0,
        }

        if 'Tag' in df.columns:
            stats['unique_tags'] = int(df['Tag'].dropna().nunique())

        if 'IO' in df.columns:
            counts = df['IO'].dropna().value_counts()
            stats['signal_types'] = {str(k): int(v) for k, v in counts.items()}

        if 'Cable' in df.columns:
            stats['cables'] = int(df['Cable'].dropna().nunique())

        if 'Grp' in df.columns:
            stats['groups'] = int(df['Grp'].dropna().nunique())

        return stats

    @staticmethod
    def normalize_tag_key(tag: Any) -> str:
        """Normalize tag for matching: trim whitespace, casefold, and standardize punctuation."""
        if tag is None or pd.isna(tag):
            return ''
        import re
        return re.sub(r'[^a-zA-Z0-9]', '', str(tag)).casefold()

    def merge_mdb_allocation(self, alloc_df: pd.DataFrame, mdb_df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """Merge MDB metadata into allocation records by normalized tag key.

        Excludes DELETED MDB records. Reports active unmatched MDB tags and allocation-only tags.
        """
        # Ensure we have copies
        a_df = alloc_df.copy()
        m_df = mdb_df.copy()

        # Detect tag column in allocation
        a_tag_col = 'Tag Name' if 'Tag Name' in a_df.columns else ('Tag' if 'Tag' in a_df.columns else a_df.columns[0])
        m_tag_col = 'Tag Number' if 'Tag Number' in m_df.columns else ('TagNumber' if 'TagNumber' in m_df.columns else ('Tag' if 'Tag' in m_df.columns else m_df.columns[0]))

        # Filter out DELETED MDB records
        status_cols = [c for c in m_df.columns if 'status' in c.lower() or 'change' in c.lower()]
        active_m_rows = []
        deleted_m_tags = []
        for _, row in m_df.iterrows():
            is_deleted = False
            for sc in status_cols:
                val = str(row.get(sc, '')).strip().upper()
                if 'DELETED' in val:
                    is_deleted = True
                    break
            if is_deleted:
                tag_val = row.get(m_tag_col, '')
                deleted_m_tags.append(str(tag_val))
            else:
                active_m_rows.append(row)

        active_mdb = pd.DataFrame(active_m_rows) if active_m_rows else pd.DataFrame(columns=m_df.columns)

        # Build normalized keys
        a_df['_norm_tag'] = a_df[a_tag_col].apply(self.normalize_tag_key)
        if not active_mdb.empty:
            active_mdb['_norm_tag'] = active_mdb[m_tag_col].apply(self.normalize_tag_key)
        else:
            active_mdb['_norm_tag'] = []

        # Map MDB fields to dict for quick lookup
        mdb_lookup = {}
        if not active_mdb.empty:
            for _, row in active_mdb.iterrows():
                nt = row['_norm_tag']
                if nt:
                    mdb_lookup[nt] = row

        merged_rows = []
        allocation_only_tags = []
        matched_mdb_norm_tags = set()

        for _, a_row in a_df.iterrows():
            nt = a_row['_norm_tag']
            orig_tag = a_row.get(a_tag_col, '')
            row_dict = a_row.to_dict()

            if nt and nt in mdb_lookup:
                matched_mdb_norm_tags.add(nt)
                m_row = mdb_lookup[nt]
                # Merge MDB fields if present
                for m_col in active_mdb.columns:
                    if m_col not in row_dict or not row_dict[m_col] or pd.isna(row_dict[m_col]):
                        val = m_row.get(m_col)
                        if not pd.isna(val):
                            row_dict[m_col] = val
            else:
                if nt:
                    allocation_only_tags.append(orig_tag)

            merged_rows.append(row_dict)

        active_unmatched_mdb = []
        if not active_mdb.empty:
            for _, m_row in active_mdb.iterrows():
                nt = m_row['_norm_tag']
                if nt and nt not in matched_mdb_norm_tags:
                    active_unmatched_mdb.append(m_row.get(m_tag_col, ''))

        merged_df = pd.DataFrame(merged_rows)
        if '_norm_tag' in merged_df.columns:
            merged_df.drop(columns=['_norm_tag'], inplace=True)

        report = {
            'allocation_only_tags': allocation_only_tags,
            'active_unmatched_mdb_tags': active_unmatched_mdb,
            'deleted_mdb_tags': deleted_m_tags,
            'matched_count': len(matched_mdb_norm_tags),
        }

        return merged_df, report
