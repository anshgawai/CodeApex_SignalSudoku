"""Workstation Renderer for Signal Sudoku.

Generates the high-density Industrial Engineering Workstation HTML
dynamically bound to real Excel I/O and allocation data models.
Fully functional, theme-adaptive, resizable diagnostics drawer, and interactive conflict inspector modal.
"""
import html
import json
import re
from typing import Dict, List, Any
import pandas as pd


# Industrial automation engineering explanations for common allocation rules
RULE_EXPLANATIONS: Dict[str, Dict[str, str]] = {
    'cable_grouping': {
        'title': 'Cable-Pair Contiguity Breached',
        'why': (
            'Multicore field cables should terminate on a single baseplate carrier. '
            'Splitting pairs across separate baseplates forces electricians to strip cable '
            'jackets across separate DIN rails, creating cabinet wiring congestion ("spaghetti routing") '
            'and compromising shield grounding against electromagnetic interference (EMI).'
        ),
        'remediation': 'Keep cable signals together on the same baseplate or adjust rule tolerance in sidebar.',
    },
    'maintain_pair_order': {
        'title': 'Cable Pair Sequence Discontinuity',
        'why': (
            'Pairs inside a cable were assigned out of numerical sequence (e.g. Pair 2 before Pair 1). '
            'This leads to irregular termination patterns, making loop checking and future field maintenance error-prone.'
        ),
        'remediation': 'Reorder signals by cable pair number in the allocation sequence.',
    },
    'enforce_segregation': {
        'title': 'Safety & Voltage Segregation Violation',
        'why': (
            'Incompatible electrical signal classes (e.g., 24VDC control vs 120VAC power, or Intrinsically '
            'Safe [IS] hazardous area loops vs non-IS signals) are sharing the same CIOC carrier without certified physical barriers. '
            'This violates IEC 60079-11 / NFPA 70 safety codes.'
        ),
        'remediation': 'Segregate hazardous area and high-voltage loops onto separate dedicated CIOC carriers.',
    },
    'spare_capacity': {
        'title': 'Spare Margin Deficit',
        'why': (
            'Carrier channel density exceeds the project reserve margin (target 10–20% spare capacity). '
            'Leaving insufficient spares prevents accommodating late commissioning additions or replacing damaged channels.'
        ),
        'remediation': 'Provision an additional modular baseplate or expand into an adjacent cabinet.',
    },
    'baseplate_capacity': {
        'title': 'Baseplate Slot Overflow',
        'why': 'Allocated signals exceed the physical 12-channel limit of the baseplate carrier.',
        'remediation': 'Move overflow channels to an adjacent baseplate with available capacity.',
    },
    'cioc_capacity': {
        'title': 'CIOC Carrier Capacity Exceeded',
        'why': 'The total number of baseplates or channels exceeds the maximum limit supported by the CIOC carrier pair (96 channels).',
        'remediation': 'Install a second CIOC carrier in the cabinet or split signals into a new cabinet.',
    },
    'unknown_io': {
        'title': 'Unmapped / Unknown I/O Electrical Specification',
        'why': (
            'The signal type indicated in the Excel sheet does not match any certified CHARM module '
            '(AI 4-20mA HART, AO, DI 24V, DO 24V, RTD, TC). The system cannot physically allocate unmapped channels.'
        ),
        'remediation': 'Submit a Technical Query (TQ) to the client lead engineer to clarify instrument electrical specs.',
    },
    'naming_uniqueness': {
        'title': 'Duplicate Tag Identifier Detected',
        'why': (
            'Multiple field devices share the exact same Tag Name in the source Excel sheet. '
            'Duplicate tags create DCS database addressing collisions and loop cross-talk.'
        ),
        'remediation': 'Resolve duplicate tag naming in the source I/O MDB Excel workbook.',
    },
}


class WorkstationRenderer:
    """Renders the high-density Engineering Workstation HTML."""

    @staticmethod
    def _io_color_class(io_type: str) -> Dict[str, str]:
        """Return slot and badge styling for a given IO type."""
        io_upper = str(io_type).upper().strip()
        if 'AI' in io_upper:
            return {
                'slot': 'bg-blue-600 dark:bg-blue-500',
                'badge': 'bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200 border-blue-300 dark:border-blue-700',
                'label': 'AI-HART' if 'HART' in io_upper else 'AI',
            }
        elif 'AO' in io_upper:
            return {
                'slot': 'bg-amber-500 dark:bg-amber-500',
                'badge': 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200 border-amber-300 dark:border-amber-700',
                'label': 'AO',
            }
        elif 'DI' in io_upper:
            return {
                'slot': 'bg-emerald-600 dark:bg-emerald-500',
                'badge': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700',
                'label': 'DI',
            }
        elif 'DO' in io_upper:
            return {
                'slot': 'bg-red-600 dark:bg-red-500',
                'badge': 'bg-red-100 text-red-800 dark:bg-red-900/60 dark:text-red-200 border-red-300 dark:border-red-700',
                'label': 'DO-24V',
            }
        elif 'RTD' in io_upper or 'TC' in io_upper:
            return {
                'slot': 'bg-purple-600 dark:bg-purple-500',
                'badge': 'bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-200 border-purple-300 dark:border-purple-700',
                'label': 'RTD/TC',
            }
        else:
            return {
                'slot': 'bg-slate-400 dark:bg-slate-500',
                'badge': 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700',
                'label': io_upper or 'I/O',
            }

    def render_workstation(
        self,
        allocation_df: pd.DataFrame,
        hardware_df: pd.DataFrame,
        validation_findings: List[Any],
        tq_list: List[Any],
        statistics: Dict[str, Any],
        filename: str = 'sample_io_mdb_clean.xlsx',
        project_id: str = 'PRJ-8420-TX-REF-03',
    ) -> str:
        """Produce the complete Workstation HTML with live data binding and interactive conflict inspector."""
        # 1. KPI Calculations
        total_signals = int(statistics.get('total_signals', len(allocation_df)))
        allocated = int(statistics.get('allocated', 0))
        unallocated = int(statistics.get('unallocated', 0))
        cabinets_count = int(statistics.get('cabinets', 0))
        alloc_pct = (allocated / total_signals * 100.0) if total_signals > 0 else 0.0

        # Diagnostics counts
        severe_errors = 0
        advisory_warnings = 0
        for f in validation_findings:
            sev = getattr(f, 'severity', '').lower()
            if sev in ['error', 'violation', 'fatal']:
                severe_errors += 1
            else:
                advisory_warnings += 1

        total_tqs = len(tq_list)
        if total_tqs > 0:
            severe_errors += total_tqs

        violations_count = severe_errors + advisory_warnings

        # Spares calculation
        total_capacity = 0
        total_used = 0
        if not hardware_df.empty:
            cab_hw = hardware_df[hardware_df['Type'] == 'Cabinet']
            if not cab_hw.empty:
                total_capacity = int(cab_hw['Capacity'].sum())
                total_used = int(cab_hw['Used'].sum())
            else:
                cioc_hw = hardware_df[hardware_df['Type'] == 'CIOC']
                total_capacity = int(cioc_hw['Capacity'].sum()) if not cioc_hw.empty else (total_signals + 24)
                total_used = allocated

        spare_pct = ((total_capacity - total_used) / total_capacity * 100.0) if total_capacity > 0 else 18.2
        spare_pct = max(0.0, min(100.0, spare_pct))
        used_pct = 100.0 - spare_pct

        # 2. Extract Cabinets and Topology
        cabinets = [str(c) for c in allocation_df['Cabinet'].dropna().unique() if str(c).strip()]
        if not cabinets:
            cabinets = ['CAB-01 (Marshaling East)']

        cabinet_data: Dict[str, Any] = {}
        for cab in cabinets:
            cab_signals = allocation_df[allocation_df['Cabinet'] == cab]
            baseplates = [str(bp) for bp in cab_signals['Baseplate'].dropna().unique() if str(bp).strip()]
            baseplates = sorted(baseplates)

            bp_cards = []
            for bp_idx in range(1, 9):
                bp_name = baseplates[bp_idx - 1] if bp_idx - 1 < len(baseplates) else f'BP-{bp_idx:02d}'
                bp_sigs = cab_signals[cab_signals['Baseplate'] == bp_name] if bp_name in baseplates else pd.DataFrame()

                has_warning = False
                has_error = False
                for f in validation_findings:
                    if getattr(f, 'affected_item', '') == bp_name or bp_name in str(getattr(f, 'explanation', '')):
                        severity = str(getattr(f, 'severity', '')).lower()
                        if severity in ['error', 'violation', 'fatal']:
                            has_error = True
                        elif severity == 'warning':
                            has_warning = True

                slots = []
                used_slots_count = 0
                for slot_num in range(1, 13):
                    sig_match = pd.DataFrame()
                    if not bp_sigs.empty:
                        for _, row in bp_sigs.iterrows():
                            c_str = str(row.get('CHARM', ''))
                            m = re.search(r'CH-(\d+)', c_str)
                            if m and int(m.group(1)) == slot_num:
                                sig_match = row
                                break
                            elif str(slot_num) == c_str or f'{slot_num:02d}' == c_str:
                                sig_match = row
                                break

                    if not sig_match.empty:
                        used_slots_count += 1
                        io_type = str(sig_match.get('IO', 'AI'))
                        c_info = self._io_color_class(io_type)
                        tag = html.escape(str(sig_match.get('Tag', '')))
                        cable = html.escape(str(sig_match.get('Cable', '')))
                        pair = html.escape(str(sig_match.get('Pair', '')))
                        slots.append({
                            'num': f'CH{slot_num:02d}',
                            'color': c_info['slot'],
                            'tag': tag,
                            'spare': False,
                            'title': f'{slot_num:02d}: {tag} ({io_type}) | Cable: {cable} (P{pair})',
                        })
                    else:
                        slots.append({
                            'num': f'CH{slot_num:02d}',
                            'color': 'bg-slate-100 dark:bg-slate-800 border border-dashed border-slate-300 dark:border-slate-600',
                            'tag': '',
                            'spare': True,
                            'title': f'CH{slot_num:02d}: Available Spare Slot',
                        })

                bp_cards.append({
                    'id': f'BP-{bp_idx:02d}',
                    'name': bp_name,
                    'used_count': f'{used_slots_count:02d}/12',
                    'has_warning': has_warning,
                    'has_error': has_error,
                    'slots': slots,
                })

            cioc_a_stat = '92/96'
            cioc_b_stat = '84/96'
            if not hardware_df.empty:
                ciocs = hardware_df[(hardware_df['Type'] == 'CIOC') & (hardware_df['Parent'] == cab)]
                if len(ciocs) >= 1:
                    cioc_a_stat = f"{ciocs.iloc[0]['Used']}/{ciocs.iloc[0]['Capacity']}"
                if len(ciocs) >= 2:
                    cioc_b_stat = f"{ciocs.iloc[1]['Used']}/{ciocs.iloc[1]['Capacity']}"

            cabinet_data[cab] = {
                'cioc_a': cioc_a_stat,
                'cioc_b': cioc_b_stat,
                'baseplates': bp_cards,
            }

        first_cab = cabinets[0]
        initial_bp_cards = cabinet_data[first_cab]['baseplates']

        # 3. Build Conflict Explanations Database for JavaScript modal
        conflict_map: Dict[str, Any] = {}

        # 4. Format Signals Rows (matching Excel columns)
        rows_html = []
        for idx, (_, row) in enumerate(allocation_df.iterrows(), start=1):
            tag = str(row.get('Tag', ''))
            io_val = str(row.get('IO', 'AI'))
            cable = str(row.get('Cable', '---'))
            pair = str(row.get('Pair', '---'))
            group = str(row.get('Group', '---'))
            cab = str(row.get('Cabinet', '---'))
            cioc = str(row.get('CIOC', '---'))[-3:] if str(row.get('CIOC', '')) else '---'
            baseplate = str(row.get('Baseplate', '---'))

            charm_val = str(row.get('CHARM', '---'))
            m = re.search(r'CH-(\d+)', charm_val)
            slot = f"CH-{int(m.group(1)):02d}" if m else charm_val

            charm_model = str(row.get('CHARM_Type', 'Standard CHARM'))
            status = str(row.get('Status', 'Allocated')).upper()
            val_status = str(row.get('Validation_Status', '')).lower()
            notes = str(row.get('Notes', ''))
            seg = str(row.get('Segregation', 'A'))

            # Keep allocation outcome separate from post-allocation findings:
            # a warning (for example, a cable spanning baseplates) does not
            # invalidate a successful slot assignment.
            is_unallocated = status != 'ALLOCATED'
            matched_findings = []
            for f in validation_findings:
                aff = str(getattr(f, 'affected_item', ''))
                exp = str(getattr(f, 'explanation', ''))
                severity = str(getattr(f, 'severity', '')).lower()
                if (aff in [tag, cable] or (tag and tag in exp)) and severity in ['error', 'violation', 'fatal', 'warning']:
                    matched_findings.append(f)

            error_findings = [
                f for f in matched_findings
                if str(getattr(f, 'severity', '')).lower() in ['error', 'violation', 'fatal']
            ]
            warning_findings = [
                f for f in matched_findings
                if str(getattr(f, 'severity', '')).lower() == 'warning'
            ]
            has_status_error = ('violation' in val_status) or ('error' in val_status)
            is_conflict = bool(error_findings) or has_status_error
            matched_finding = (error_findings or warning_findings or [None])[0]
            finding_reason = str(getattr(matched_finding, 'explanation', '')) if matched_finding else ''
            has_warning = bool(warning_findings) and not is_conflict

            # Make finding details available from either a conflict or warning badge.
            if is_conflict or has_warning or is_unallocated:
                rule_key = str(getattr(matched_finding, 'rule_name', 'unknown_io' if is_unallocated else 'general_rule')).lower()
                rule_meta = RULE_EXPLANATIONS.get(rule_key, {
                    'title': rule_key.replace('_', ' ').title(),
                    'why': 'This signal configuration violates engineering allocation rules.',
                    'remediation': getattr(matched_finding, 'suggested_action', 'Check signal electrical attributes or adjust project tolerances.') if matched_finding else 'Check signal parameters in source Excel file.'
                })

                conflict_map[tag] = {
                    'tag': tag,
                    'io': io_val,
                    'cable': cable,
                    'pair': pair,
                    'group': group,
                    'cab': cab,
                    'baseplate': baseplate,
                    'slot': slot,
                    'status': status,
                    'rule_title': rule_meta['title'],
                    'rule_code': getattr(matched_finding, 'finding_id', 'ERR-CONF'),
                    'explanation': finding_reason or f"Signal could not be allocated in {cab}.",
                    'why': rule_meta['why'],
                    'remediation': getattr(matched_finding, 'suggested_action', rule_meta['remediation']) if matched_finding else rule_meta['remediation'],
                    'severity': str(getattr(matched_finding, 'severity', 'error' if is_conflict else 'warning')).lower(),
                }

            constraint_text = finding_reason if finding_reason else (notes if notes else f"Segregation Class {seg}")
            constraint_esc = html.escape(constraint_text)

            tag_esc = html.escape(tag)
            cable_esc = html.escape(cable)
            pair_esc = html.escape(pair)
            group_esc = html.escape(group)
            cab_esc = html.escape(cab)
            cioc_esc = html.escape(cioc)
            baseplate_esc = html.escape(baseplate)
            slot_esc = html.escape(slot)
            charm_model_esc = html.escape(charm_model)
            seg_esc = html.escape(seg)

            tr_class = "hover:bg-blue-50/50 dark:hover:bg-slate-800/60 transition-colors h-7 border-b border-slate-200 dark:border-slate-700/60"
            if is_unallocated:
                tr_class = "hover:bg-amber-50/50 dark:hover:bg-amber-950/30 transition-colors h-7 bg-amber-50/20 dark:bg-amber-950/20 border-b border-slate-200 dark:border-slate-700/60 cursor-pointer"
                status_badge = (
                    f'<button onclick="inspectConflict(\'{tag_esc}\')" class="text-amber-800 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 px-1.5 py-0.5 '
                    f'rounded-[2px] text-[10px] font-sans font-medium flex items-center space-x-1 hover:bg-amber-200 transition-colors" title="Click to inspect unallocated reason">'
                    f'<span class="w-1.5 h-1.5 bg-amber-500 rounded-full"></span><span>UNALLOCATED ℹ</span></button>'
                )
            elif is_conflict:
                tr_class = "bg-red-50/60 dark:bg-red-950/30 hover:bg-red-100/60 dark:hover:bg-red-950/60 transition-colors h-7 border-l-2 border-l-red-600 border-b border-slate-200 dark:border-slate-700/60 cursor-pointer"
                status_badge = (
                    f'<button onclick="inspectConflict(\'{tag_esc}\')" class="text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900/60 border border-red-300 dark:border-red-700 px-1.5 py-0.5 '
                    f'rounded-[2px] text-[10px] font-sans font-semibold flex items-center space-x-1 hover:bg-red-200 dark:hover:bg-red-800/80 transition-colors" title="Click to inspect conflict analysis">'
                    f'<span class="w-1.5 h-1.5 bg-red-600 dark:bg-red-400 rounded-full animate-ping"></span><span>CONFLICT ℹ</span></button>'
                )
            elif status == 'ALLOCATED':
                status_badge = (
                    '<span class="text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 px-1.5 py-0.5 '
                    'rounded-[2px] text-[10px] font-sans font-medium flex items-center space-x-1">'
                    '<span class="w-1.5 h-1.5 bg-emerald-600 dark:bg-emerald-400 rounded-full"></span><span>ALLOCATED</span></span>'
                )
                if has_warning:
                    status_badge += (
                        f'<button onclick="inspectConflict(\'{tag_esc}\')" class="ml-1 text-amber-800 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 px-1.5 py-0.5 '
                        f'rounded-[2px] text-[10px] font-sans font-medium hover:bg-amber-200 dark:hover:bg-amber-900/60 transition-colors" title="Click to inspect validation warning">WARNING ℹ</button>'
                    )
                    tr_class = "bg-amber-50/30 dark:bg-amber-950/10 hover:bg-amber-50/60 dark:hover:bg-amber-950/30 transition-colors h-7 border-l-2 border-l-amber-400 border-b border-slate-200 dark:border-slate-700/60"
            else:
                status_badge = ''

            io_style = self._io_color_class(io_val)
            badge_cls = io_style['badge']
            io_badge = f'<span class="{badge_cls} text-[10px] px-1 py-0.2 rounded-[2px] font-semibold border">{html.escape(io_val)}</span>'

            row_filter_type = 'conflict' if (is_conflict and not is_unallocated) else ('unallocated' if is_unallocated else 'allocated')
            onclick_attr = f'onclick="onRowClick(\'{tag_esc}\', {str(is_conflict or has_warning).lower()})"'

            rows_html.append(f"""
              <tr class="{tr_class} signal-row" id="row-{tag_esc}" {onclick_attr} data-status="{row_filter_type}" data-tag="{tag_esc.lower()}" data-io="{io_val.lower()}" data-cable="{cable_esc.lower()}" data-group="{group_esc.lower()}" data-cab="{cab_esc}" data-bp="{baseplate_esc}" data-seg="{seg_esc.lower()}">
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 text-slate-400 text-center font-mono">{idx:04d}</td>
                <td class="px-2.5 py-1 border-r border-slate-200 dark:border-slate-700 font-semibold text-slate-900 dark:text-slate-100 font-mono">{tag_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700">{io_badge}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-mono">{cable_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 text-center font-mono">{pair_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-mono">{group_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 font-medium font-mono">{cab_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 font-mono">{cioc_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 font-medium font-mono">{baseplate_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 font-bold font-mono">{slot_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 truncate max-w-[120px] font-mono" title="{charm_model_esc}">{charm_model_esc}</td>
                <td class="px-2 py-1 border-r border-slate-200 dark:border-slate-700 font-sans text-slate-600 dark:text-slate-400 text-[10px] truncate max-w-[200px]" title="{constraint_esc}">{constraint_esc}</td>
                <td class="px-2 py-1">{status_badge}</td>
              </tr>
            """)

        signals_tbody = "\n".join(rows_html)

        # 5. Format Diagnostics Items with DEEP ENGINEERING EXPLANATIONS
        diag_items_html = []
        for idx, f in enumerate(validation_findings, start=1):
            sev = getattr(f, 'severity', 'warning').lower()
            rule_key = str(getattr(f, 'rule_name', 'RULE_CHECK')).lower()
            affected = html.escape(str(getattr(f, 'affected_item', 'Hardware')))
            finding_text = html.escape(str(getattr(f, 'explanation', 'Constraint check failed')))

            rule_meta = RULE_EXPLANATIONS.get(rule_key, {
                'title': rule_key.replace('_', ' ').title(),
                'why': 'This configuration breaches established I&C allocation safety or engineering guidelines.',
                'remediation': getattr(f, 'suggested_action', 'Review affected items and adjust rule parameters.')
            })

            title_str = html.escape(rule_meta['title'])
            why_str = html.escape(rule_meta['why'])
            remed_str = html.escape(getattr(f, 'suggested_action', rule_meta['remediation']))

            is_error = sev in ['error', 'violation', 'fatal']
            badge = (
                f'<span class="px-1.5 py-0.5 bg-red-100 dark:bg-red-900/60 text-red-800 dark:text-red-200 border border-red-300 dark:border-red-700 font-bold rounded-[2px] text-[9px] font-mono">ERR-{idx:03d}</span>'
                if is_error else
                f'<span class="px-1.5 py-0.5 bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-700 font-bold rounded-[2px] text-[9px] font-mono">WRN-{idx:03d}</span>'
            )

            diag_items_html.append(f"""
              <div class="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-start justify-between">
                  <div class="space-y-1">
                    <div class="flex items-center space-x-2">
                      {badge}
                      <span class="text-slate-900 dark:text-slate-100 font-semibold text-[11px]">{title_str}:</span>
                      <code class="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-800 dark:text-slate-200 font-mono text-[10px]">{affected}</code>
                    </div>
                    <p class="text-slate-700 dark:text-slate-300 text-[11px] leading-tight">{finding_text}</p>
                    <div class="text-[10px] bg-slate-50 dark:bg-slate-800/80 p-1.5 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400">
                      <span class="font-bold text-slate-800 dark:text-slate-200">Industrial Automation Impact:</span> {why_str}
                      <div class="mt-1 text-blue-700 dark:text-blue-400 font-medium"><b>Remediation:</b> {remed_str}</div>
                    </div>
                  </div>
                  <button onclick="filterByItem('{affected}')" class="ml-3 shrink-0 font-sans text-[10px] bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 px-2 py-1 rounded text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-700 font-semibold transition-colors">
                    Filter Affected Signals →
                  </button>
                </div>
              </div>
            """)

        # Add TQs with engineering explanation
        for idx, tq in enumerate(tq_list, start=1):
            tq_id = html.escape(str(getattr(tq, 'tq_id', f'TQ-{idx:03d}')))
            category = html.escape(str(getattr(tq, 'category', 'Hardware Specification')))
            reason = html.escape(str(getattr(tq, 'reason', 'Technical clarification required')))
            item = html.escape(str(getattr(tq, 'affected_item', 'Signal Tag')))
            action = html.escape(str(getattr(tq, 'suggested_action', 'Clarify with project engineering lead')))

            diag_items_html.append(f"""
              <div class="px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-start justify-between">
                  <div class="space-y-1">
                    <div class="flex items-center space-x-2">
                      <span class="px-1.5 py-0.5 bg-purple-100 dark:bg-purple-900/60 text-purple-800 dark:text-purple-200 border border-purple-300 dark:border-purple-700 font-bold rounded-[2px] text-[9px] font-mono">{tq_id}</span>
                      <span class="text-slate-900 dark:text-slate-100 font-semibold text-[11px]">Technical Query [{category}]:</span>
                      <code class="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-800 dark:text-slate-200 font-mono text-[10px]">{item}</code>
                    </div>
                    <p class="text-slate-700 dark:text-slate-300 text-[11px] leading-tight">{reason}</p>
                    <div class="text-[10px] bg-slate-50 dark:bg-slate-800/80 p-1.5 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400">
                      <span class="font-bold text-slate-800 dark:text-slate-200">Engineering Action Required:</span> {action}
                    </div>
                  </div>
                  <button onclick="filterByItem('{item}')" class="ml-3 shrink-0 font-sans text-[10px] bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 px-2 py-1 rounded text-purple-700 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-slate-700 font-semibold transition-colors">
                    Inspect Item →
                  </button>
                </div>
              </div>
            """)

        if not diag_items_html:
            diag_items_html.append("""
              <div class="px-4 py-3 text-emerald-700 dark:text-emerald-400 font-sans text-[11px] flex items-center space-x-2 bg-emerald-50/50 dark:bg-emerald-950/20">
                <span class="w-2.5 h-2.5 bg-emerald-600 rounded-full"></span>
                <span class="font-medium">All engineering rules and physical capacity constraints are fully satisfied. Zero active violations or open technical queries.</span>
              </div>
            """)

        diagnostics_body = "\n".join(diag_items_html)

        # 6. Build Initial Baseplates HTML Grid
        bp_html_list = []
        for bp in initial_bp_cards:
            bp_border = "border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40"
            bp_title_class = "text-slate-700 dark:text-slate-300"
            if bp['has_error']:
                bp_border = "border-red-300 dark:border-red-800 bg-red-50/30 dark:bg-red-950/20"
                bp_title_class = "text-red-700 dark:text-red-400"
            elif bp['has_warning']:
                bp_border = "border-amber-300 dark:border-amber-800 bg-amber-50/30 dark:bg-amber-950/20"
                bp_title_class = "text-amber-700 dark:text-amber-400"

            slot_divs = []
            for s in bp['slots']:
                tag_attr = html.escape(s.get('tag', ''))
                slot_divs.append(
                    f'<div class="h-3.5 {s["color"]} rounded-[1px] transition-transform hover:scale-125 cursor-pointer slot-box" '
                    f'data-tag="{tag_attr}" title="{s["title"]}" onclick="highlightSignal(\'{tag_attr}\')"></div>'
                )
            slots_grid = "\n".join(slot_divs)

            bp_html_list.append(f"""
              <div class="border {bp_border} rounded-[2px] p-1.5 baseplate-card cursor-pointer hover:border-blue-400 transition-colors" onclick="filterByBaseplate('{bp['name']}')" title="Click to filter signals on {bp['name']}">
                <div class="flex justify-between text-[9px] font-mono text-slate-500 dark:text-slate-400 mb-1">
                  <span class="font-bold {bp_title_class}">{bp['id']} {'⚠' if (bp['has_warning'] or bp['has_error']) else ''}</span>
                  <span>{bp['used_count']}</span>
                </div>
                <div class="grid grid-cols-6 gap-0.5">
                  {slots_grid}
                </div>
              </div>
            """)
        baseplates_grid_html = "\n".join(bp_html_list)

        cabinet_options_html = "\n".join(
            [f"<option value='{html.escape(c)}'>{html.escape(c)}</option>" for c in cabinets]
        )

        cabinet_data_json = json.dumps(cabinet_data)
        conflict_map_json = json.dumps(conflict_map)

        # 7. Complete Theme-Adaptive Self-Contained HTML Document with Resizable Drawer and Conflict Modal
        return f"""<!DOCTYPE html>
<html lang="en" class="h-full dark">
<head>
  <meta charset="UTF-8">
  <title>Engineering Workstation — Signal Sudoku</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {{
      darkMode: 'class',
      theme: {{
        extend: {{
          fontFamily: {{
            mono: ['IBM Plex Mono', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
            sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
          }}
        }}
      }}
    }}
  </script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body {{
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }}
    .font-mono {{
      font-family: 'IBM Plex Mono', monospace;
    }}
    ::-webkit-scrollbar {{ width: 6px; height: 6px; }}
    ::-webkit-scrollbar-track {{ background: transparent; }}
    ::-webkit-scrollbar-thumb {{ background: rgba(150, 160, 180, 0.3); border-radius: 3px; }}
    ::-webkit-scrollbar-thumb:hover {{ background: rgba(150, 160, 180, 0.5); }}
    
    .highlight-active {{
      background-color: rgba(59, 130, 246, 0.25) !important;
      outline: 2px solid #3b82f6;
    }}

    /* Resizer styling */
    .resizer-line {{
      cursor: row-resize;
      user-select: none;
    }}
    .resizer-line:hover .resizer-bar,
    .resizer-line.is-resizing .resizer-bar {{
      background-color: #3b82f6 !important;
    }}
  </style>
</head>
<body class="h-full flex flex-col text-slate-900 dark:text-slate-100 text-xs overflow-hidden select-none bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[3px] relative">

  <!-- INTERACTIVE CONFLICT MODAL / SLIDE-OVER -->
  <div id="conflictModal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md shadow-2xl max-w-lg w-full overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
      <!-- Modal Header -->
      <div class="px-4 py-3 bg-red-50 dark:bg-red-950/50 border-b border-red-200 dark:border-red-800/60 flex items-center justify-between">
        <div class="flex items-center space-x-2">
          <span class="w-2.5 h-2.5 bg-red-600 rounded-full animate-ping"></span>
          <span class="font-bold text-sm text-red-900 dark:text-red-200" id="modalTitle">Conflict Analysis</span>
          <span id="modalCode" class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-red-200 dark:bg-red-900 text-red-900 dark:text-red-100 font-bold">ERR-001</span>
        </div>
        <button onclick="closeConflictModal()" class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 font-bold text-lg leading-none p-1">×</button>
      </div>

      <!-- Modal Body -->
      <div class="p-4 space-y-3.5 overflow-y-auto max-h-[70vh]">
        <!-- Target Signal Hardware Path -->
        <div class="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded border border-slate-200 dark:border-slate-700">
          <div class="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1">Target Instrument Path</div>
          <div class="font-mono text-xs flex flex-wrap items-center gap-1.5" id="modalPath">
            <!-- populated by JS -->
          </div>
        </div>

        <!-- Issue Details -->
        <div>
          <div class="text-[10px] text-slate-500 uppercase tracking-wider font-semibold mb-1">Conflict Description</div>
          <div id="modalDesc" class="text-xs text-slate-800 dark:text-slate-200 font-medium"></div>
        </div>

        <!-- Industrial Impact -->
        <div class="bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/50 rounded p-2.5">
          <div class="text-[10px] text-amber-900 dark:text-amber-300 uppercase tracking-wider font-bold mb-1 flex items-center space-x-1">
            <span>⚙️ Industrial Automation Engineering Impact</span>
          </div>
          <p id="modalWhy" class="text-[11px] text-amber-900/90 dark:text-amber-200/90 leading-relaxed"></p>
        </div>

        <!-- Remediation -->
        <div class="bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800/50 rounded p-2.5">
          <div class="text-[10px] text-blue-900 dark:text-blue-300 uppercase tracking-wider font-bold mb-1 flex items-center space-x-1">
            <span>🛠️ Recommended Engineering Resolution</span>
          </div>
          <p id="modalRemed" class="text-[11px] text-blue-900/90 dark:text-blue-200/90 leading-relaxed"></p>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="px-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 flex justify-end space-x-2">
        <button id="modalFilterBtn" class="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-sans text-xs font-medium transition-colors">
          Filter to this Signal & Cable
        </button>
        <button onclick="closeConflictModal()" class="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300 hover:bg-slate-100 rounded font-sans text-xs font-medium transition-colors">
          Dismiss
        </button>
      </div>
    </div>
  </div>

  <!-- TOP APP HEADER (Real Functional Header) -->
  <header class="h-10 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3 flex items-center justify-between shrink-0 z-20">
    <div class="flex items-center space-x-3">
      <!-- Industrial App Logo -->
      <div class="flex items-center space-x-2">
        <div class="w-5 h-5 bg-slate-900 dark:bg-slate-800 rounded-[2px] flex items-center justify-center text-white font-mono font-bold text-[10px]">
          IO∷
        </div>
        <span class="font-bold text-[12px] tracking-tight text-slate-900 dark:text-slate-100">ENGINEERING WORKSTATION</span>
      </div>

      <div class="h-4 w-[1px] bg-slate-200 dark:bg-slate-700"></div>

      <!-- Active File Context -->
      <div class="flex items-center space-x-1.5 text-slate-600 dark:text-slate-300 font-mono text-[10px] bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-0.5 rounded-[2px]">
        <svg class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
        <span>{html.escape(filename)}</span>
      </div>

      <div class="flex items-center space-x-1 text-slate-500 dark:text-slate-400 font-mono text-[10px]">
        <span>PRJ:</span>
        <span class="font-semibold text-slate-800 dark:text-slate-200">{html.escape(project_id)}</span>
      </div>
    </div>

    <!-- Real Functional Actions -->
    <div class="flex items-center space-x-2">
      <button onclick="toggleDrawer()" class="px-2 py-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-[2px] font-sans text-[10px] flex items-center space-x-1 transition-colors">
        <svg class="w-3 h-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
        <span>Diagnostics Panel ({violations_count})</span>
      </button>

      <button onclick="resetAllFilters()" class="px-2 py-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-[2px] font-sans text-[10px] flex items-center space-x-1 transition-colors">
        <svg class="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
        <span>Reset Filters</span>
      </button>
    </div>
  </header>

  <!-- PRIMARY CANVAS -->
  <main class="flex-1 flex flex-col min-w-0 bg-slate-50 dark:bg-slate-900 overflow-hidden">

    <!-- KPI RIBBON / METRIC STRIP -->
  <section class="h-8 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-3 flex items-center justify-between font-mono text-[10.5px] shrink-0">
      <div class="flex items-center space-x-5">
        <div class="flex items-center space-x-1">
          <span class="text-slate-400 font-sans uppercase text-[9.5px]">Total Signals:</span>
          <span class="font-bold text-slate-900 dark:text-slate-100">{total_signals:,}</span>
        </div>
        <div class="h-3 w-[1px] bg-slate-200 dark:bg-slate-700"></div>
        <div class="flex items-center space-x-1">
          <span class="text-slate-400 font-sans uppercase text-[9.5px]">Allocated:</span>
          <span class="font-bold text-emerald-700 dark:text-emerald-400">{allocated:,}</span>
          <span class="text-slate-400 text-[9.5px]">({alloc_pct:.1f}%)</span>
        </div>
        <div class="h-3 w-[1px] bg-slate-200 dark:bg-slate-700"></div>
        <div class="flex items-center space-x-1">
          <span class="text-slate-400 font-sans uppercase text-[9.5px]">Unallocated:</span>
          <span class="font-bold {'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 px-1 rounded border border-amber-200 dark:border-amber-800' if unallocated > 0 else 'text-slate-500'}">{unallocated}</span>
        </div>
        <div class="h-3 w-[1px] bg-slate-200 dark:bg-slate-700"></div>
        <div class="flex items-center space-x-1">
          <span class="text-slate-400 font-sans uppercase text-[9.5px]">Cabinets:</span>
          <span class="font-bold text-slate-800 dark:text-slate-200">{cabinets_count}</span>
        </div>
        <div class="h-3 w-[1px] bg-slate-200 dark:bg-slate-700"></div>
        <div class="flex items-center space-x-1">
          <span class="text-slate-400 font-sans uppercase text-[9.5px]">Rule Violations:</span>
          <span class="font-bold {'text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/60 px-1 rounded border border-red-200 dark:border-red-800' if violations_count > 0 else 'text-emerald-700 dark:text-emerald-400'}">{violations_count} Active</span>
        </div>
      </div>

      <div class="flex items-center space-x-3">
        <span class="text-slate-400 font-sans uppercase text-[9.5px]">Spare Capacity:</span>
        <div class="w-24 h-2 bg-slate-200 dark:bg-slate-700 rounded-sm overflow-hidden flex">
          <div class="bg-blue-600 dark:bg-blue-500 h-full" style="width: {used_pct:.1f}%"></div>
          <div class="bg-emerald-400 dark:bg-emerald-500 h-full" style="width: {spare_pct:.1f}%"></div>
        </div>
        <span class="text-slate-700 dark:text-slate-300 font-bold text-[10px]">{spare_pct:.1f}%</span>
      </div>
    </section>

    <!-- HARDWARE TOPOLOGY STRIP: CAB -> CIOC -> BASEPLATE -> CHARM -->
    <section class="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 p-2.5 shrink-0 flex space-x-3">
      <!-- Cabinet Selector & Bus Density -->
      <div class="w-60 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[2px] p-2 flex flex-col justify-between">
        <div class="flex justify-between items-center mb-1">
          <span class="text-[9.5px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Cabinet Enclosure</span>
          <span class="text-[9px] font-mono bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-1 rounded">DeltaV Carrier</span>
        </div>
        <div class="my-1">
          <select id="cabinetSelect" onchange="onCabinetChange(this.value)" class="w-full font-mono font-bold text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-[2px] px-2 py-1 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-600">
            {cabinet_options_html}
          </select>
        </div>
        <div class="text-[9.5px] text-slate-500 dark:text-slate-400 flex justify-between mt-1">
          <span>CIOC-1A: <b id="ciocAStat" class="font-mono text-slate-800 dark:text-slate-200">{cabinet_data[first_cab]['cioc_a']}</b></span>
          <span>CIOC-1B: <b id="ciocBStat" class="font-mono text-slate-800 dark:text-slate-200">{cabinet_data[first_cab]['cioc_b']}</b></span>
        </div>
      </div>

      <!-- Baseplate Slot Grid -->
      <div class="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-[2px] p-2 flex flex-col justify-between overflow-x-auto">
        <div class="flex justify-between items-center mb-1">
          <span id="topologyTitle" class="text-[9.5px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Channel Utilization Map — {html.escape(first_cab)}</span>
          <div class="flex items-center space-x-3 text-[9.5px] font-mono text-slate-600 dark:text-slate-300">
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-blue-600 rounded-[1px]"></span><span>AI</span></span>
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-amber-500 rounded-[1px]"></span><span>AO</span></span>
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-emerald-600 rounded-[1px]"></span><span>DI</span></span>
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-red-600 rounded-[1px]"></span><span>DO</span></span>
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-purple-600 rounded-[1px]"></span><span>RTD</span></span>
            <span class="flex items-center space-x-1"><span class="w-2 h-2 bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-[1px]"></span><span>Spare</span></span>
          </div>
        </div>

        <!-- 8 Baseplates Grid -->
        <div id="baseplateGrid" class="grid grid-cols-8 gap-1.5">
          {baseplates_grid_html}
        </div>
      </div>
    </section>

    <!-- HIGH-DENSITY SIGNAL DATA GRID -->
    <section class="flex-1 bg-white dark:bg-slate-900 flex flex-col min-h-0 border-t border-slate-200 dark:border-slate-800">
      <!-- Table Toolbar -->
      <div class="h-8 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 px-3 flex items-center justify-between">
        <div class="flex items-center space-x-3">
          <span id="rowsCounter" class="font-bold text-[10px] text-slate-700 dark:text-slate-300 uppercase tracking-wider font-mono">Signals ({len(allocation_df):,} Rows)</span>
          <div class="h-3.5 w-[1px] bg-slate-300 dark:bg-slate-700"></div>

          <!-- Quick Filter Pills -->
          <div class="flex items-center space-x-1">
            <button onclick="setFilter('all', this)" class="filter-pill px-1.5 py-0.5 bg-blue-50 dark:bg-blue-900/40 border border-blue-400 dark:border-blue-600 text-blue-700 dark:text-blue-300 rounded-[2px] font-medium text-[10px]">All</button>
            <button onclick="setFilter('conflict', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 rounded-[2px] font-medium text-[10px] hover:bg-red-50 dark:hover:bg-red-950/40">Conflicts ({severe_errors})</button>
            <button onclick="setFilter('unallocated', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 rounded-[2px] font-medium text-[10px] hover:bg-amber-50">Unallocated ({unallocated})</button>
            <div class="h-3 w-[1px] bg-slate-300 dark:bg-slate-700 mx-0.5"></div>
            <button onclick="setFilter('ai', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px]">AI</button>
            <button onclick="setFilter('di', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px]">DI</button>
            <button onclick="setFilter('do', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px]">DO</button>
            <button onclick="setFilter('ao', this)" class="filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px]">AO</button>
          </div>
        </div>

        <!-- Working Tag Filter / Search Bar -->
        <div class="flex items-center space-x-2">
          <div class="relative">
            <input id="searchInput" oninput="applySearch(this.value)" type="text" placeholder="Search tag, cable, group..." class="w-56 pl-5 pr-5 py-0.5 text-[11px] font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-[2px] text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-600">
            <svg class="w-3 h-3 text-slate-400 absolute left-1.5 top-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            <button onclick="clearSearch()" class="absolute right-1.5 top-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs">×</button>
          </div>
        </div>
      </div>

      <!-- Virtualized Scrollable Table Container -->
      <div class="flex-1 overflow-auto bg-white dark:bg-slate-900">
        <table class="w-full border-collapse text-left font-mono text-[10.5px]">
          <thead class="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-10 font-sans text-[9.5px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
            <tr>
              <th class="w-10 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700 text-slate-400 text-center">#</th>
              <th class="px-2.5 py-1.5 border-r border-slate-200 dark:border-slate-700">Signal Tag</th>
              <th class="w-20 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">I/O Type</th>
              <th class="px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">Field Cable</th>
              <th class="w-12 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700 text-center">Pair</th>
              <th class="w-20 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">Group</th>
              <th class="w-16 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">Cabinet</th>
              <th class="w-12 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">CIOC</th>
              <th class="w-16 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">Baseplt</th>
              <th class="w-12 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">Slot</th>
              <th class="w-24 px-2 py-1.5 border-r border-slate-200 dark:border-slate-700">CHARM Model</th>
              <th class="px-2 py-1.5 border-r border-slate-200 dark:border-slate-700 font-sans">Engineering Constraint / Note</th>
              <th class="w-28 px-2 py-1.5 font-sans">Status</th>
            </tr>
          </thead>
          <tbody id="signalsTbody" class="divide-y divide-slate-100 dark:divide-slate-800">
            {signals_tbody}
          </tbody>
        </table>
      </div>
    </section>

    <!-- RESIZABLE RESIZER DRAG HANDLE -->
    <div id="drawerResizer" class="resizer-line h-2 bg-slate-200 dark:bg-slate-800 hover:bg-blue-400 dark:hover:bg-blue-600 transition-colors flex items-center justify-center shrink-0" title="Drag up or down to resize the diagnostics drawer">
      <div class="resizer-bar w-12 h-1 bg-slate-400 dark:bg-slate-600 rounded-full transition-colors"></div>
    </div>

    <!-- DIAGNOSTIC / CONSTRAINTS ENGINE DRAWER (RESIZABLE) -->
    <footer id="diagDrawer" class="h-36 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-col shrink-0">
      <!-- Drawer Header -->
      <div class="h-7 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-3 flex items-center justify-between text-[10.5px]">
        <div class="flex items-center space-x-3">
          <span class="font-bold text-[10px] text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
            <span>Diagnostics & Solver Validation Audit</span>
          </span>
          <div class="h-3 w-[1px] bg-slate-300 dark:bg-slate-700"></div>
          <span class="text-red-700 dark:text-red-400 font-bold text-[10px]">{severe_errors} Severe Errors</span>
          <span class="text-amber-700 dark:text-amber-400 font-bold text-[10px]">{advisory_warnings} Advisory Warnings</span>
          <span class="text-slate-500 dark:text-slate-400 text-[10px]">Real-Time Rules Verification</span>
        </div>
        <div class="flex items-center space-x-2">
          <button onclick="toggleMaximizeDrawer()" title="Maximize / Restore Drawer" class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-0.5">
            <svg id="drawerMaxIcon" class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path></svg>
          </button>
          <button onclick="toggleDrawer()" title="Collapse / Expand" class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-0.5">
            <svg id="drawerChevron" class="w-3.5 h-3.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
          </button>
        </div>
      </div>

      <!-- Diagnostic List with Deep Explanations -->
      <div id="diagList" class="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-[11px]">
        {diagnostics_body}
      </div>
    </footer>

  </main>

  <script>
    const cabinetData = {cabinet_data_json};
    const conflictMap = {conflict_map_json};

    let currentFilter = 'all';
    let currentQuery = '';
    let selectedCabinet = '{first_cab}';
    let selectedBaseplate = '';

    // Conflict Inspector Modal
    function inspectConflict(tag) {{
      const data = conflictMap[tag];
      if (!data) return;

      document.getElementById('modalTitle').textContent = data.rule_title;
      document.getElementById('modalCode').textContent = data.rule_code;
      document.getElementById('modalDesc').textContent = data.explanation;
      document.getElementById('modalWhy').textContent = data.why;
      document.getElementById('modalRemed').textContent = data.remediation;

      const pathEl = document.getElementById('modalPath');
      pathEl.innerHTML = `
        <span class="px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-100 font-bold">${{data.tag}} (${{data.io}})</span>
        <span>➜</span>
        <span class="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">Cable: ${{data.cable}} (Pair ${{data.pair}})</span>
        <span>➜</span>
        <span class="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">${{data.cab}}</span>
        <span>➜</span>
        <span class="px-1.5 py-0.5 rounded bg-purple-100 dark:bg-purple-900 text-purple-900 dark:text-purple-100 font-bold">${{data.baseplate}} (${{data.slot}})</span>
      `;

      const filterBtn = document.getElementById('modalFilterBtn');
      filterBtn.onclick = function() {{
        closeConflictModal();
        filterByItem(data.tag);
      }};

      document.getElementById('conflictModal').classList.remove('hidden');
    }}

    function closeConflictModal() {{
      document.getElementById('conflictModal').classList.add('hidden');
    }}

    function onRowClick(tag, isConflict) {{
      if (isConflict && conflictMap[tag]) {{
        inspectConflict(tag);
      }} else {{
        highlightSignal(tag);
      }}
    }}

    function onCabinetChange(cabName) {{
      selectedCabinet = cabName;
      selectedBaseplate = '';
      const data = cabinetData[cabName];
      if (!data) return;
      document.getElementById('ciocAStat').textContent = data.cioc_a;
      document.getElementById('ciocBStat').textContent = data.cioc_b;
      document.getElementById('topologyTitle').textContent = 'Channel Utilization Map — ' + cabName;

      renderBaseplates(data.baseplates);
      updateTableFilter();
    }}

    function renderBaseplates(baseplates) {{
      const grid = document.getElementById('baseplateGrid');
      grid.innerHTML = baseplates.map(bp => {{
        const bpBorder = bp.has_error ? 'border-red-300 dark:border-red-800 bg-red-50/30 dark:bg-red-950/20'
          : bp.has_warning ? 'border-amber-300 dark:border-amber-700 bg-amber-50/20 dark:bg-amber-950/10'
          : 'border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40';
        const titleClass = bp.has_error ? 'text-red-700 dark:text-red-400'
          : bp.has_warning ? 'text-amber-700 dark:text-amber-500'
          : 'text-slate-700 dark:text-slate-300';
        const slotsHtml = bp.slots.map(s => `
          <div class="h-3.5 ${{s.color}} rounded-[1px] transition-transform hover:scale-125 cursor-pointer slot-box" 
               data-tag="${{s.tag}}" title="${{s.title}}" onclick="highlightSignal('${{s.tag}}')"></div>
        `).join('');

        return `
          <div class="border ${{bpBorder}} rounded-[2px] p-1.5 baseplate-card cursor-pointer hover:border-blue-400 transition-colors" onclick="filterByBaseplate('${{bp.name}}')" title="Click to filter signals on ${{bp.name}}">
            <div class="flex justify-between text-[9px] font-mono text-slate-500 dark:text-slate-400 mb-1">
              <span class="font-bold ${{titleClass}}">${{bp.id}} ${{bp.has_error ? '⚠' : (bp.has_warning ? '△' : '')}}</span>
              <span>${{bp.used_count}}</span>
            </div>
            <div class="grid grid-cols-6 gap-0.5">
              ${{slotsHtml}}
            </div>
          </div>
        `;
      }}).join('');
    }}

    function setFilter(type, btn) {{
      currentFilter = type;
      selectedBaseplate = '';
      document.querySelectorAll('.filter-pill').forEach(b => {{
        b.className = 'filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px] hover:bg-slate-50';
      }});
      btn.className = 'filter-pill px-1.5 py-0.5 bg-blue-50 dark:bg-blue-900/40 border border-blue-400 dark:border-blue-600 text-blue-700 dark:text-blue-300 rounded-[2px] font-medium text-[10px]';
      updateTableFilter();
    }}

    function applySearch(query) {{
      currentQuery = query.toLowerCase().trim();
      updateTableFilter();
    }}

    function clearSearch() {{
      const inp = document.getElementById('searchInput');
      inp.value = '';
      currentQuery = '';
      updateTableFilter();
    }}

    function filterByBaseplate(bpName) {{
      selectedBaseplate = bpName;
      document.getElementById('searchInput').value = bpName;
      currentQuery = bpName.toLowerCase();
      updateTableFilter();
    }}

    function filterByItem(itemName) {{
      const clean = itemName.toLowerCase().trim();
      document.getElementById('searchInput').value = itemName;
      currentQuery = clean;
      updateTableFilter();
      const el = document.getElementById('signalsTbody');
      el.scrollIntoView({{ behavior: 'smooth' }});
    }}

    function highlightSignal(tag) {{
      if (!tag) return;
      document.querySelectorAll('.signal-row').forEach(r => r.classList.remove('highlight-active'));
      const target = document.getElementById('row-' + tag);
      if (target) {{
        target.classList.add('highlight-active');
        target.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
      }} else {{
        document.getElementById('searchInput').value = tag;
        currentQuery = tag.toLowerCase();
        updateTableFilter();
      }}
    }}

    function resetAllFilters() {{
      currentFilter = 'all';
      currentQuery = '';
      selectedBaseplate = '';
      document.getElementById('searchInput').value = '';
      document.querySelectorAll('.filter-pill').forEach((b, idx) => {{
        if (idx === 0) {{
          b.className = 'filter-pill px-1.5 py-0.5 bg-blue-50 dark:bg-blue-900/40 border border-blue-400 dark:border-blue-600 text-blue-700 dark:text-blue-300 rounded-[2px] font-medium text-[10px]';
        }} else {{
          b.className = 'filter-pill px-1.5 py-0.5 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-[2px] font-medium text-[10px]';
        }}
      }});
      updateTableFilter();
    }}

    function updateTableFilter() {{
      const rows = document.querySelectorAll('.signal-row');
      let visibleCount = 0;
      rows.forEach(r => {{
        const status = r.getAttribute('data-status');
        const tag = r.getAttribute('data-tag') || '';
        const io = r.getAttribute('data-io') || '';
        const cable = r.getAttribute('data-cable') || '';
        const group = r.getAttribute('data-group') || '';
        const cab = r.getAttribute('data-cab') || '';
        const bp = r.getAttribute('data-bp') || '';
        const seg = r.getAttribute('data-seg') || '';

        // Status / Type filter
        let matchFilter = true;
        if (currentFilter === 'conflict') matchFilter = (status === 'conflict');
        else if (currentFilter === 'unallocated') matchFilter = (status === 'unallocated');
        else if (currentFilter === 'ai') matchFilter = io.includes('ai');
        else if (currentFilter === 'di') matchFilter = io.includes('di');
        else if (currentFilter === 'do') matchFilter = io.includes('do');
        else if (currentFilter === 'ao') matchFilter = io.includes('ao');

        // Cabinet filter (if not "all cabinets")
        let matchCab = true;
        if (selectedCabinet && !selectedCabinet.includes('All')) {{
          matchCab = (cab === selectedCabinet) || (status === 'unallocated');
        }}

        // Search Query filter (matches tag, cable, group, baseplate, or IO)
        let matchSearch = true;
        if (currentQuery) {{
          const cleanQ = currentQuery.replace(/\\*/g, '');
          matchSearch = tag.includes(cleanQ) || cable.includes(cleanQ) || group.includes(cleanQ) || bp.toLowerCase().includes(cleanQ) || io.includes(cleanQ);
        }}

        if (matchFilter && matchCab && matchSearch) {{
          r.style.display = '';
          visibleCount++;
        }} else {{
          r.style.display = 'none';
        }}
      }});
      document.getElementById('rowsCounter').textContent = `Signals (${{visibleCount}} Shown)`;
    }}

    // Resizable Diagnostics Drawer Logic
    const drawer = document.getElementById('diagDrawer');
    const resizer = document.getElementById('drawerResizer');
    let isResizing = false;
    let startY = 0;
    let startHeight = 0;
    let drawerHeightBeforeCollapse = 144;
    let isMaximized = false;

    resizer.addEventListener('mousedown', function(e) {{
      isResizing = true;
      startY = e.clientY;
      startHeight = drawer.offsetHeight;
      resizer.classList.add('is-resizing');
      document.body.style.cursor = 'row-resize';
      e.preventDefault();
    }});

    window.addEventListener('mousemove', function(e) {{
      if (!isResizing) return;
      const delta = startY - e.clientY;
      const newHeight = Math.max(28, Math.min(420, startHeight + delta));
      drawer.style.height = newHeight + 'px';
      drawerHeightBeforeCollapse = newHeight > 40 ? newHeight : drawerHeightBeforeCollapse;
    }});

    window.addEventListener('mouseup', function() {{
      if (isResizing) {{
        isResizing = false;
        resizer.classList.remove('is-resizing');
        document.body.style.cursor = '';
      }}
    }});

    function toggleDrawer() {{
      const chevron = document.getElementById('drawerChevron');
      if (drawer.offsetHeight > 35) {{
        drawerHeightBeforeCollapse = drawer.offsetHeight;
        drawer.style.height = '28px';
        chevron.style.transform = 'rotate(180deg)';
      }} else {{
        drawer.style.height = (drawerHeightBeforeCollapse || 144) + 'px';
        chevron.style.transform = 'rotate(0deg)';
      }}
    }}

    function toggleMaximizeDrawer() {{
      const chevron = document.getElementById('drawerChevron');
      isMaximized = !isMaximized;
      if (isMaximized) {{
        drawer.style.height = '380px';
        chevron.style.transform = 'rotate(0deg)';
      }} else {{
        drawer.style.height = '144px';
        chevron.style.transform = 'rotate(0deg)';
      }}
    }}
  </script>
</body>
</html>
"""
