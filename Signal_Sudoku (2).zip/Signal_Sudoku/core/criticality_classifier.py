"""Equipment criticality classifier for Signal Sudoku.

Classifies signals into priority tiers based on configurable candidate rules
and explicit engineer overrides. Does NOT infer safety criticality from
Risk Area, Segregation, NON-IS/IS, instrument type, or the word 'General'.
Uncertain records default to 'Unassessed'.

Criticality tiers:
  P1 Safety/Protection
  P2 Control/Final Element
  P3 Process Measurement/Operator Alarm
  P4 Monitoring/Indication
  Unassessed

Lifecycle statuses (separate from criticality):
  Active, Spare, Inactive, Deleted

Criticality status:
  confirmed  - from explicit engineer override
  inferred   - from candidate rule (must be marked for review)
  unassessed - no match found
"""
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple
import re

CRITICALITY_TIERS = [
    'P1 Safety/Protection',
    'P2 Control/Final Element',
    'P3 Process Measurement/Operator Alarm',
    'P4 Monitoring/Indication',
    'Unassessed',
]
LIFECYCLE_STATUSES = ['Active', 'Spare', 'Inactive', 'Deleted']

# Default candidate rules: each maps a field+value to a suggested tier.
# These are INFERRED, never confirmed. Engineer must review.
DEFAULT_CANDIDATE_RULES: List[Dict] = [
    {
        'field': 'Process_Function',
        'match': 'control valve',         # case-insensitive contains
        'tier': 'P2 Control/Final Element',
        'note': 'Control Valve — inferred P2; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'shutdown valve',
        'tier': 'P2 Control/Final Element',
        'note': 'Shutdown Valve — inferred P2; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'flow measurement',
        'tier': 'P3 Process Measurement/Operator Alarm',
        'note': 'Flow Measurement — inferred P3; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'pressure measurement',
        'tier': 'P3 Process Measurement/Operator Alarm',
        'note': 'Pressure Measurement — inferred P3; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'temperature measurement',
        'tier': 'P3 Process Measurement/Operator Alarm',
        'note': 'Temperature Measurement — inferred P3; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'level measurement',
        'tier': 'P3 Process Measurement/Operator Alarm',
        'note': 'Level Measurement — inferred P3; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'indication',
        'tier': 'P4 Monitoring/Indication',
        'note': 'Indication — inferred P4; confirm with process engineer',
    },
    {
        'field': 'Process_Function',
        'match': 'monitor',
        'tier': 'P4 Monitoring/Indication',
        'note': 'Monitor — inferred P4; confirm with process engineer',
    },
]


@dataclass
class CriticalityResult:
    tier: str = 'Unassessed'                  # one of CRITICALITY_TIERS
    status: str = 'unassessed'                # 'confirmed', 'inferred', 'unassessed'
    lifecycle: str = 'Active'                  # one of LIFECYCLE_STATUSES
    note: str = ''                             # human-readable reasoning


class CriticalityClassifier:
    """Classify equipment criticality with explicit override support.
    
    Safety note: This classifier NEVER infers P1 Safety/Protection from
    field data. P1 must always come from an explicit engineer override.
    The following fields are intentionally NOT used for inference:
    Risk Area, Segregation, NON-IS/IS, Instrument Type Description,
    the word 'General'.
    """

    # Tag-status values that indicate spare/inactive lifecycle
    SPARE_STATUSES = frozenset({'spare', 'reserve', 'standby'})
    INACTIVE_STATUSES = frozenset({'inactive'})
    # Tag-status values that indicate deleted records
    DELETED_STATUSES = frozenset({'deleted', 'del', 'removed'})

    def __init__(
        self,
        overrides: Optional[Dict[str, str]] = None,
        candidate_rules: Optional[List[Dict]] = None,
    ) -> None:
        """
        Args:
            overrides: Dict mapping normalized tag key -> confirmed criticality tier.
                       e.g. {'100-psh-001': 'P1 Safety/Protection'}
            candidate_rules: List of rule dicts with keys:
                             field, match (case-insensitive contains), tier, note.
                             Defaults to DEFAULT_CANDIDATE_RULES.
        """
        self._overrides: Dict[str, str] = {}
        if overrides:
            for tag, tier in overrides.items():
                self._overrides[self._normalize_key(tag)] = tier

        self._rules = candidate_rules if candidate_rules is not None else DEFAULT_CANDIDATE_RULES

    @staticmethod
    def _normalize_key(tag) -> str:
        """Normalize tag for lookup: strip, casefold, collapse whitespace."""
        if tag is None:
            return ''
        return ' '.join(str(tag).strip().split()).casefold()

    def classify(self, row: dict) -> CriticalityResult:
        """Classify a single signal row.

        Args:
            row: Dict with keys such as Tag, Tag_Status, Process_Function,
                 Instrument_Type, Alarm_Priority, etc. Missing keys are safe.

        Returns:
            CriticalityResult with tier, status, lifecycle, note.
        """
        tag = str(row.get('Tag', row.get('Tag Name', ''))).strip()
        tag_norm = self._normalize_key(tag)

        # Determine lifecycle from Tag_Status
        tag_status_raw = str(row.get('Tag_Status', row.get('Tag Status', ''))).strip().lower()
        lifecycle = 'Active'
        if tag_status_raw in self.DELETED_STATUSES:
            lifecycle = 'Deleted'
        elif tag_status_raw in self.SPARE_STATUSES:
            lifecycle = 'Spare'
        elif 'inactive' in tag_status_raw:
            lifecycle = 'Inactive'

        # Spare/Inactive/Deleted: no active criticality assignment
        if lifecycle in ('Spare', 'Inactive', 'Deleted'):
            return CriticalityResult(
                tier='Unassessed',
                status='unassessed',
                lifecycle=lifecycle,
                note=f'Tag lifecycle status is {lifecycle}; criticality not assessed.',
            )

        # Check confirmed override first
        if tag_norm and tag_norm in self._overrides:
            confirmed_tier = self._overrides[tag_norm]
            return CriticalityResult(
                tier=confirmed_tier,
                status='confirmed',
                lifecycle='Active',
                note=f'Confirmed by engineer override.',
            )

        # Run candidate inference rules (inferred — must be reviewed)
        for rule in self._rules:
            field_val = str(row.get(rule['field'], '')).lower()
            match_str = rule['match'].lower()
            if match_str in field_val:
                return CriticalityResult(
                    tier=rule['tier'],
                    status='inferred',
                    lifecycle='Active',
                    note=f"[INFERRED — review required] {rule['note']}",
                )

        # Default: unassessed
        return CriticalityResult(
            tier='Unassessed',
            status='unassessed',
            lifecycle='Active',
            note='No matching rule or override found; manual classification required.',
        )

    def classify_dataframe(self, df) -> list:
        """Classify all rows in a DataFrame. Returns list of CriticalityResult."""
        return [self.classify(row.to_dict()) for _, row in df.iterrows()]

    def add_override(self, tag: str, tier: str) -> None:
        """Add or update a confirmed override for a tag."""
        if tier not in CRITICALITY_TIERS:
            raise ValueError(f"Unknown tier: {tier!r}. Must be one of {CRITICALITY_TIERS}")
        self._overrides[self._normalize_key(tag)] = tier
