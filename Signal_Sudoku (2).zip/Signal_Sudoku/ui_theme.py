"""Visual theme for Signal Sudoku (styling only - no logic, no layout changes).

Call ``inject_theme()`` once, right after ``st.set_page_config``.
To revert the look completely, remove that call (and the import) from app.py.
"""
import streamlit as st

_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

:root {
  --bg: #FAFAF8;
  --surface: #FFFFFF;
  --surface-2: #F2F1EE;
  --ink: #111111;
  --muted: #8A8A86;
  --line: #ECEBE8;
  --accent: #5B47E8;
  --accent-hover: #4B38D4;
  --accent-soft: #EFEDFD;
  --ok: #4CC26A;
  --radius: 16px;
  --pill: 999px;
  --ease: cubic-bezier(.22, 1, .36, 1);
  --shadow: 0 1px 2px rgba(17,17,17,.04), 0 8px 24px rgba(17,17,17,.05);
  --shadow-hover: 0 2px 4px rgba(17,17,17,.05), 0 14px 32px rgba(91,71,232,.12);
}

html { scroll-behavior: smooth; }
html, body, .stApp, button, input, textarea, select {
  font-family: 'Plus Jakarta Sans', -apple-system, 'Segoe UI', Roboto, sans-serif;
}

/* SIGNALSUDOKU_UIUX: BEGIN
   Defect: 'keyboard_double_arrow_right' heading/sidebar icon rendered as raw literal text.
   Root cause: '[class*="st-"]' matched Streamlit Emotion cache classes (st-emotion-cache-...) and
   forced 'Plus Jakarta Sans', wiping out the 'Material Symbols Rounded' icon ligature font.
   Fix: Removed '[class*="st-"]' from the global font rule and explicitly enforced
   'Material Symbols Rounded' with ligatures on all stIconMaterial elements.
   Unchanged: Preserves sidebar expand/collapse, page title typography, and responsive layout.
*/
[data-testid="stIconMaterial"],
[data-testid="stIconMaterial"] *,
[class*="material-symbols"],
.material-symbols-rounded {
  font-family: "Material Symbols Rounded" !important;
  font-feature-settings: "liga" !important;
  -webkit-font-feature-settings: "liga" !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  letter-spacing: normal !important;
  text-transform: none !important;
  white-space: nowrap !important;
  word-wrap: normal !important;
  direction: ltr !important;
  -webkit-font-smoothing: antialiased !important;
}
/* SIGNALSUDOKU_UIUX: END */

.stApp { background: var(--bg); color: var(--ink); }

/* Header bar blends into the page */
header[data-testid="stHeader"] { background: rgba(250,250,248,.8); backdrop-filter: blur(10px); }

/* ---------- Typography ---------- */
h1 {
  font-weight: 800 !important;
  letter-spacing: -0.04em !important;
  line-height: 1.02 !important;
  font-size: clamp(2.6rem, 5vw, 4.4rem) !important;
  color: var(--ink);
  padding-bottom: .25rem !important;
}
h2, h3, h4 { font-weight: 700 !important; letter-spacing: -0.025em !important; color: var(--ink); }
[data-testid="stCaptionContainer"], .stCaption, small { color: var(--muted) !important; }
p, li, label { color: var(--ink); }
a { color: var(--accent); text-decoration: none; transition: opacity .2s var(--ease); }
a:hover { opacity: .75; }
hr { border-color: var(--line) !important; }

/* ---------- Buttons (pill, like the reference) ---------- */
.stButton > button, .stDownloadButton > button, [data-testid="stBaseButton-secondary"] {
  border-radius: var(--pill) !important;
  border: 1px solid var(--line) !important;
  background: var(--surface) !important;
  color: var(--ink) !important;
  font-weight: 600;
  padding: .55rem 1.35rem !important;
  box-shadow: var(--shadow);
  transition: transform .35s var(--ease), box-shadow .35s var(--ease),
              background-color .25s var(--ease), border-color .25s var(--ease), color .25s var(--ease);
}
.stButton > button:hover, .stDownloadButton > button:hover {
  transform: translateY(-2px);
  border-color: var(--accent) !important;
  color: var(--accent) !important;
  box-shadow: var(--shadow-hover);
}
.stButton > button:hover p, .stDownloadButton > button:hover p {
  color: var(--accent) !important;
}
.stButton > button:active, .stDownloadButton > button:active { transform: translateY(0) scale(.98); }

/* SIGNALSUDOKU_UIUX: BEGIN
   Defect: 'Allocate signals' button text appeared black on dark purple background.
   Root cause: Global 'p { color: var(--ink); }' rule styled paragraph inside the button with black (#111111).
   Fix: Targeted selectors ensuring white text (#FFFFFF) on primary buttons and all child elements.
   Unchanged: Preserves allocation button trigger, container width, and allocation execution.
*/
.stButton > button[data-testid="stBaseButton-primary"],
button[data-testid="stBaseButton-primary"],
[data-testid="stBaseButton-primary"],
.stButton > button[kind="primary"],
.st-key-allocate_signals_btn button {
  background: var(--accent) !important;
  border-color: var(--accent) !important;
  color: #FFFFFF !important;
}

.stButton > button[data-testid="stBaseButton-primary"] *,
button[data-testid="stBaseButton-primary"] *,
[data-testid="stBaseButton-primary"] *,
.stButton > button[kind="primary"] *,
.st-key-allocate_signals_btn button * {
  color: #FFFFFF !important;
}

.stButton > button[data-testid="stBaseButton-primary"]:hover,
button[data-testid="stBaseButton-primary"]:hover,
[data-testid="stBaseButton-primary"]:hover,
.stButton > button[kind="primary"]:hover,
.st-key-allocate_signals_btn button:hover {
  background: var(--accent-hover) !important;
  border-color: var(--accent-hover) !important;
  color: #FFFFFF !important;
}

.stButton > button[data-testid="stBaseButton-primary"]:hover *,
button[data-testid="stBaseButton-primary"]:hover *,
[data-testid="stBaseButton-primary"]:hover *,
.stButton > button[kind="primary"]:hover *,
.st-key-allocate_signals_btn button:hover * {
  color: #FFFFFF !important;
}
/* SIGNALSUDOKU_UIUX: END */

/* ---------- Tabs: pill style with gliding highlight ---------- */
[data-baseweb="tab-list"] {
  gap: .35rem; background: var(--surface-2); padding: .3rem;
  border-radius: var(--pill); width: fit-content; max-width: 100%;
}
[data-baseweb="tab"] {
  border-radius: var(--pill) !important; padding: .45rem 1.1rem !important;
  color: var(--muted) !important; font-weight: 600;
  transition: color .25s var(--ease), background-color .35s var(--ease);
}
[data-baseweb="tab"]:hover { color: var(--ink) !important; }
[data-baseweb="tab"][aria-selected="true"] {
  color: var(--ink) !important; background: var(--surface) !important; box-shadow: var(--shadow);
}
[data-baseweb="tab-highlight"] { background: transparent !important; }
[data-baseweb="tab-border"] { display: none; }
[data-baseweb="tab-panel"] { animation: sx-fade-up .5s var(--ease) both; }

/* ---------- Cards: expanders, metrics, alerts, dataframes ---------- */
/* SIGNALSUDOKU_UIUX: BEGIN
   Defect: Input Checks expander header and expand/collapse arrow overlap and raw icon text.
   Root cause: Overridden icon font caused chevron icon to render as literal text strings
   ('keyboard_arrow_right' / 'keyboard_arrow_down') colliding with the expander title.
   Fix: Restored Material Symbols font and enforced summary flex layout, proper icon sizing,
   and visual gap between chevron arrow and expander title.
   Unchanged: Preserves native st.expander() expand/collapse behavior, findings count, and data table.
*/
[data-testid="stExpander"] {
  border: 1px solid var(--line) !important; border-radius: var(--radius) !important;
  background: var(--surface); box-shadow: var(--shadow); overflow: hidden;
  transition: box-shadow .35s var(--ease), transform .35s var(--ease);
}
[data-testid="stExpander"]:hover { box-shadow: var(--shadow-hover); }
[data-testid="stExpander"] summary {
  font-weight: 600;
  transition: background-color .25s var(--ease);
  display: flex !important;
  align-items: center !important;
  gap: 0.5rem !important;
}
[data-testid="stExpander"] summary:hover { background: var(--accent-soft); }
[data-testid="stExpander"] summary [data-testid="stIconMaterial"] {
  flex-shrink: 0 !important;
  font-size: 1.25rem !important;
  width: 1.25rem !important;
  height: 1.25rem !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
}
/* SIGNALSUDOKU_UIUX: END */

[data-testid="stMetric"] {
  background: var(--surface); border: 1px solid var(--line); border-radius: var(--radius);
  padding: 1rem 1.2rem; box-shadow: var(--shadow);
  transition: transform .35s var(--ease), box-shadow .35s var(--ease);
}
[data-testid="stMetric"]:hover { transform: translateY(-3px); box-shadow: var(--shadow-hover); }
[data-testid="stMetricValue"] { font-weight: 800; letter-spacing: -0.03em; }
[data-testid="stMetricLabel"] { color: var(--muted); }

[data-testid="stAlert"] { border-radius: var(--radius); border: 1px solid var(--line); }
[data-testid="stDataFrame"] {
  border: 1px solid var(--line); border-radius: var(--radius); overflow: hidden; box-shadow: var(--shadow);
}

/* ---------- Inputs ---------- */
[data-baseweb="input"], [data-baseweb="select"] > div, [data-baseweb="textarea"] {
  border-radius: 12px !important; border-color: var(--line) !important; background: var(--surface) !important;
  transition: box-shadow .25s var(--ease), border-color .25s var(--ease);
}
[data-baseweb="input"]:focus-within, [data-baseweb="select"] > div:focus-within {
  border-color: var(--accent) !important; box-shadow: 0 0 0 4px var(--accent-soft);
}

/* SIGNALSUDOKU_UIUX: BEGIN
   Defect: Duplicated upload control ('uploadupload' text collision).
   Root cause: Upload button embedded an icon element with text 'upload' that rendered as literal
   text when Material Symbols font was overridden, interlocking with the label 'Upload'.
   Fix: Restored Material Symbols font on stIconMaterial and added flex alignment ensuring
   the upload icon and label render cleanly side-by-side with no overlap or duplication.
   Unchanged: Preserves real st.file_uploader, supported formats (.xlsx, .xlsm, .xls), file validation,
   and downstream allocation pipeline.
*/
[data-testid="stFileUploaderDropzone"] {
  border: 1.5px dashed #D6D4EE; border-radius: var(--radius); background: var(--surface);
  transition: background-color .3s var(--ease), border-color .3s var(--ease), transform .3s var(--ease);
}
[data-testid="stFileUploaderDropzone"]:hover { background: var(--accent-soft); border-color: var(--accent); }
[data-testid="stFileUploaderDropzone"] button {
  display: inline-flex !important;
  align-items: center !important;
  gap: 0.4rem !important;
}
/* SIGNALSUDOKU_UIUX: END */

/* ---------- Sidebar ---------- */
[data-testid="stSidebar"] { background: var(--surface); border-right: 1px solid var(--line); }

/* ---------- Progress / spinner accents ---------- */
[data-testid="stProgress"] div[role="progressbar"] > div { background: var(--accent); transition: width .6s var(--ease); }

/* ---------- Motion ---------- */
@keyframes sx-fade-up {
  from { opacity: 0; transform: translateY(14px); }
  to   { opacity: 1; transform: translateY(0); }
}
.block-container { animation: sx-fade-up .7s var(--ease) both; }
[data-testid="stElementContainer"] { animation: sx-fade-up .55s var(--ease) both; }
[data-testid="stElementContainer"]:nth-child(2) { animation-delay: .04s; }
[data-testid="stElementContainer"]:nth-child(3) { animation-delay: .08s; }
[data-testid="stElementContainer"]:nth-child(4) { animation-delay: .12s; }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; scroll-behavior: auto !important; }
}
"""


def inject_theme() -> None:
    st.markdown(f"<style>{_CSS}</style>", unsafe_allow_html=True)
